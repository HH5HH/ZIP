"use strict";

(function installZipSlackRuntimeConfig() {
  if (typeof window === "undefined") return;

  // Bundled defaults so packaged ZIP builds do not depend on local-only files.
  if (!window.ZIP_PASS_AI_SLACK_APP_ID) {
    window.ZIP_PASS_AI_SLACK_APP_ID = "A0AGPACM3UG";
  }
  if (!window.ZIP_PASS_AI_EXPECTED_SLACK_TEAM_ID) {
    window.ZIP_PASS_AI_EXPECTED_SLACK_TEAM_ID = "T02CAQ0B2";
  }
  if (!window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_ID) {
    window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_ID = "2418816376.10567352717968";
  }
  if (!window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_SECRET) {
    // Keep empty in git-tracked source. Internal distribution ZIP injects this
    // from git-ignored slack-runtime-config.local.js.
    window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_SECRET = "";
  }
  if (!window.ZIP_PASS_AI_SLACK_OIDC_SCOPE) {
    window.ZIP_PASS_AI_SLACK_OIDC_SCOPE = "openid profile email";
  }
  if (!window.ZIP_PASS_AI_SLACK_OIDC_REDIRECT_PATH) {
    window.ZIP_PASS_AI_SLACK_OIDC_REDIRECT_PATH = "slack-openid";
  }
  // Tokens are intentionally not hardcoded; provide via runtime/localStorage secrets.
})();


/*
 * Local-only Slack OpenID config for ZIP.
 * This file is git-ignored and must never be committed.
 */
(function () {
  if (typeof window === "undefined") return;
  window.ZIP_PASS_AI_SLACK_APP_ID = "A0AGPACM3UG";
  // Optional: set only if you need strict team pinning (example: "T123ABC45").
  window.ZIP_PASS_AI_EXPECTED_SLACK_TEAM_ID = "";
  window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_ID = "2418816376.10567352717968";
  window.ZIP_PASS_AI_SLACK_OIDC_CLIENT_SECRET = "31520173933cb712899d53c26e36a936";
  window.ZIP_PASS_AI_SLACK_OIDC_SCOPE = "openid profile email";
  window.ZIP_PASS_AI_SLACK_OIDC_REDIRECT_PATH = "slack-openid";
  // Optional: enables direct Slack API sends for @ME without requiring a Slack tab relay.
  window.ZIP_PASS_AI_SLACK_BOT_TOKEN = "xoxb-2418816376-10532730455235-QH65XcW6vkRftiG1kSjJG4VX";
  window.ZIP_PASS_AI_SLACK_USER_TOKEN = "xoxp-2418816376-162362805667-10567398737600-d21f924e93d977fa2652466f253aac4f";
})();
