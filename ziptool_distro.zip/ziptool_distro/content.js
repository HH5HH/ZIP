(function () {
  "use strict";

  if (window.__ZIP_CONTENT_LOADED__) return;
  window.__ZIP_CONTENT_LOADED__ = true;

  const BASE = "https://adobeprimetime.zendesk.com";
  const ME_URL = BASE + "/api/v2/users/me.json";
  const SESSION_URL = (typeof window !== "undefined" && window.location && window.location.origin
    ? window.location.origin
    : BASE) + "/api/v2/users/me/session";
  const SESSION_PATH = "/api/v2/users/me/session";
  const TICKET_URL_PREFIX = BASE + "/agent/tickets/";
  const JIRA_ENG_TICKET_FIELD_ID = "22790243";
  const JIRA_BROWSE_URL_PREFIX = "https://jira.corp.adobe.com/browse/";
  const SLACK_WEB_API_ORIGIN = "https://slack.com";
  const SLACK_DEFAULT_WORKSPACE_ORIGIN = "https://adobedx.slack.com";
  const SLACK_DEFAULT_FINAL_MARKER_REGEX = "FINAL_RESPONSE";
  const SLACK_BRIDGE_EVENT_NAME = "zip-slack-token";
  const SLACK_BRIDGE_MESSAGE_TYPE = "ZIP_SLACK_TOKEN_BRIDGE";
  const SLACK_TOKEN_BRIDGE_SCRIPT_ID = "zip-slack-token-bridge-script";
  const SLACK_TOKEN_BRIDGE_SCRIPT_PATH = "slack-token-bridge.js";
  const ZIP_KEY_BANNER_ID = "zip-key-required-banner";
  const REQUESTOR_ORG_ENRICHMENT_FLAG_STORAGE_KEY = "zip.feature.requestor_org_enrichment.v1";
  const REQUESTOR_ORG_ENRICHMENT_FLAG_CACHE_TTL_MS = 60 * 1000;
  const REQUESTOR_ORG_TRANSLATION_CACHE_TTL_MS = 6 * 60 * 60 * 1000;
  const ZENDESK_FETCH_TIMEOUT_MS = 25000;
  const REQUESTOR_ORG_METRICS_HISTORY_LIMIT = 24;

  let slackTokenBridgeInstalled = false;
  let slackTokenBridgeListenerInstalled = false;
  let slackCapturedToken = "";
  const slackTokenTeamIdByToken = new Map();
  const slackTokenUserIdByToken = new Map();
  const slackMentionUserIdCache = new Map();
  let requestorOrgFeatureFlagCache = {
    loaded: false,
    loadedAt: 0,
    value: true
  };
  let requestorOrgTranslationCache = null;
  let requestorOrgTranslatorAdapter = null;
  const requestorOrgMetricsHistory = [];
  let zendeskObserversInstalled = false;
  let zendeskNetworkHooksInstalled = false;
  let zendeskDomObserverInstalled = false;
  let zendeskSessionProbeTimerId = null;
  let zendeskSessionProbeInFlight = false;
  let lastZendeskSessionSignalKey = "";
  let lastZendeskSessionSignalAt = 0;
  let lastZendeskSessionProbeAt = 0;
  let lastZendeskSessionStatus = 0;
  const ZENDESK_SESSION_SIGNAL_DEDUPE_MS = 1500;
  const ZENDESK_PROBE_MIN_INTERVAL_MS = 1500;
  const ZENDESK_LOGGED_OUT_PROBE_COOLDOWN_MS = 12000;

  function waitMs(delayMs) {
    const timeout = Math.max(0, Math.trunc(Number(delayMs) || 0));
    return new Promise((resolve) => {
      setTimeout(resolve, timeout);
    });
  }

  function getChromeRuntime() {
    try {
      if (typeof chrome === "undefined" || !chrome || !chrome.runtime) return null;
      return chrome.runtime;
    } catch (_) {
      return null;
    }
  }

  function sendRuntimeMessage(message, callback) {
    const runtime = getChromeRuntime();
    if (!runtime || typeof runtime.sendMessage !== "function") {
      if (typeof callback === "function") callback(undefined, "runtime_unavailable");
      return false;
    }
    try {
      runtime.sendMessage(message, (response) => {
        const hasRuntimeError = !!(runtime && runtime.lastError);
        const runtimeError = hasRuntimeError
          ? String((runtime && runtime.lastError && runtime.lastError.message) || "runtime_error")
          : "";
        if (typeof callback === "function") callback(response, runtimeError);
      });
      return true;
    } catch (err) {
      if (typeof callback === "function") {
        callback(undefined, err && err.message ? err.message : "runtime_send_failed");
      }
      return false;
    }
  }

  function getRuntimeUrl(path) {
    const runtime = getChromeRuntime();
    if (!runtime || typeof runtime.getURL !== "function") return "";
    try {
      return String(runtime.getURL(path || "") || "");
    } catch (_) {
      return "";
    }
  }

  async function fetchJson(url) {
    let controller = null;
    let timeoutId = null;
    try {
      if (typeof AbortController === "function") {
        controller = new AbortController();
        timeoutId = setTimeout(() => {
          try { controller.abort(); } catch (_) {}
        }, ZENDESK_FETCH_TIMEOUT_MS);
      }
      const res = await fetch(url, {
        method: "GET",
        cache: "no-store",
        credentials: "include",
        headers: { Accept: "application/json" },
        signal: controller ? controller.signal : undefined
      });
      let payload = null;
      let text = "";
      let retryAfterMs = 0;
      try {
        payload = await res.json();
      } catch (_) {
        try {
          text = await res.text();
        } catch (_) {}
      }
      try {
        const retryAfterRaw = res.headers && typeof res.headers.get === "function"
          ? String(res.headers.get("Retry-After") || "").trim()
          : "";
        if (retryAfterRaw) {
          const asNumber = Number(retryAfterRaw);
          if (Number.isFinite(asNumber) && asNumber >= 0) {
            retryAfterMs = Math.trunc(asNumber * 1000);
          } else {
            const asDate = Date.parse(retryAfterRaw);
            if (Number.isFinite(asDate)) {
              retryAfterMs = Math.max(0, asDate - Date.now());
            }
          }
        }
      } catch (_) {}
      return { ok: res.ok, status: res.status, payload, text, retryAfterMs };
    } catch (err) {
      const aborted = !!(controller && controller.signal && controller.signal.aborted);
      return {
        ok: false,
        status: 0,
        payload: null,
        text: "",
        retryAfterMs: 0,
        error: aborted ? "request_timeout" : String(err && err.message ? err.message : "fetch_failed")
      };
    } finally {
      if (timeoutId != null) clearTimeout(timeoutId);
    }
  }

  function extractUser(payload) {
    if (!payload || typeof payload !== "object") return null;
    if (payload.user && payload.user.id != null) return payload.user;
    if (payload.id != null) return payload;
    return null;
  }

  async function getMe() {
    const res = await fetchJson(ME_URL);
    if (!res.ok) return { user: null, payload: res.payload, status: res.status };
    const user = extractUser(res.payload);
    return { user: user || null, payload: res.payload, status: res.status };
  }

  function isZendeskHost(hostname) {
    const normalized = String(hostname || "").trim().toLowerCase();
    return normalized === "zendesk.com" || normalized.endsWith(".zendesk.com");
  }

  function isZendeskPage() {
    return typeof window !== "undefined"
      && window.location
      && isZendeskHost(window.location.hostname);
  }

  function isZendeskAuthPage() {
    if (!isZendeskPage() || !window.location) return false;
    const path = String(window.location.pathname || "").toLowerCase();
    return isLikelyLogoutPath(path) || path.includes("/auth/");
  }

  function parseUrlPath(input) {
    const raw = String(input || "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(raw, window.location && window.location.origin ? window.location.origin : BASE);
      return String(parsed.pathname || "").toLowerCase();
    } catch (_) {
      return "";
    }
  }

  function isSessionPath(pathname) {
    return String(pathname || "").toLowerCase().startsWith(SESSION_PATH);
  }

  function isLikelyLogoutPath(pathname) {
    const path = String(pathname || "").toLowerCase();
    if (!path) return false;
    return path.includes("/logout")
      || path.includes("/access/unauthenticated")
      || path.includes("/access/login")
      || path.includes("/signin");
  }

  function shouldEmitZendeskSessionSignal(signalKey) {
    const now = Date.now();
    if (!signalKey) return false;
    if (signalKey !== lastZendeskSessionSignalKey) {
      lastZendeskSessionSignalKey = signalKey;
      lastZendeskSessionSignalAt = now;
      return true;
    }
    if (now - lastZendeskSessionSignalAt > ZENDESK_SESSION_SIGNAL_DEDUPE_MS) {
      lastZendeskSessionSignalAt = now;
      return true;
    }
    return false;
  }

  function isAuthFailureStatus(status) {
    const numeric = Number(status) || 0;
    return numeric === 401 || numeric === 403;
  }

  function isPriorityZendeskProbeReason(reason) {
    const text = String(reason || "").toLowerCase();
    if (!text) return false;
    return text.includes("zip_session_probe")
      || text.includes("background")
      || text.includes("focus")
      || text.includes("pageshow")
      || text.includes("visibility")
      || text.includes("hashchange")
      || text.includes("popstate")
      || text.includes("login");
  }

  function getZendeskProbeDelay(reason, requestedDelayMs) {
    const now = Date.now();
    const requested = Math.max(0, Number(requestedDelayMs) || 0);
    let nextDelay = requested;
    if (lastZendeskSessionProbeAt > 0) {
      const minIntervalRemaining = (lastZendeskSessionProbeAt + ZENDESK_PROBE_MIN_INTERVAL_MS) - now;
      if (minIntervalRemaining > nextDelay) nextDelay = minIntervalRemaining;
    }
    if (isAuthFailureStatus(lastZendeskSessionStatus) && !isPriorityZendeskProbeReason(reason)) {
      const cooldownRemaining = (lastZendeskSessionProbeAt + ZENDESK_LOGGED_OUT_PROBE_COOLDOWN_MS) - now;
      if (cooldownRemaining > nextDelay) nextDelay = cooldownRemaining;
    }
    return Math.max(0, Math.trunc(nextDelay));
  }

  function emitZendeskSessionOk(payload, reason, status) {
    if (!isZendeskPage()) return;
    const responseStatus = Number(status) || 200;
    const signalKey = "ok:" + String(responseStatus) + ":" + String(reason || "session_ok");
    if (!shouldEmitZendeskSessionSignal(signalKey)) return;
    sendRuntimeMessage({
      type: "ZD_SESSION_OK",
      status: responseStatus,
      reason: String(reason || "session_ok"),
      payload: payload && typeof payload === "object" ? payload : null
    });
  }

  function emitZendeskLogout(reason, status) {
    if (!isZendeskPage()) return;
    const responseStatus = Number(status) || 401;
    const signalKey = "logout:" + String(responseStatus) + ":" + String(reason || "logout_detected");
    if (!shouldEmitZendeskSessionSignal(signalKey)) return;
    sendRuntimeMessage({
      type: "ZD_LOGOUT",
      status: responseStatus,
      reason: String(reason || "logout_detected")
    });
  }

  async function probeZendeskSession(options) {
    const opts = options && typeof options === "object" ? options : {};
    if (!isZendeskPage()) {
      return { ok: false, status: 0, payload: null, error: "Not a Zendesk tab." };
    }
    const url = String(opts.url || SESSION_URL);
    const result = await fetchJson(url);
    const status = Number(result.status) || 0;
    lastZendeskSessionProbeAt = Date.now();
    lastZendeskSessionStatus = status;
    if (status === 200) {
      emitZendeskSessionOk(result.payload, opts.reason || "session_probe_200", status);
    } else if (status === 401 || status === 403) {
      emitZendeskLogout(opts.reason || "session_probe_unauthorized", status);
    }
    return {
      ok: status === 200,
      status,
      payload: result.payload || null
    };
  }

  function scheduleZendeskSessionProbe(reason, delayMs) {
    if (!isZendeskPage()) return;
    if (zendeskSessionProbeTimerId != null) {
      clearTimeout(zendeskSessionProbeTimerId);
      zendeskSessionProbeTimerId = null;
    }
    const delay = getZendeskProbeDelay(reason, delayMs);
    zendeskSessionProbeTimerId = setTimeout(() => {
      zendeskSessionProbeTimerId = null;
      if (zendeskSessionProbeInFlight) return;
      zendeskSessionProbeInFlight = true;
      probeZendeskSession({ reason: reason || "scheduled_probe" })
        .catch(() => {})
        .finally(() => {
          zendeskSessionProbeInFlight = false;
        });
    }, delay);
  }

  function inspectZendeskAuthResponse(urlValue, status, payload, reason) {
    if (!isZendeskPage()) return;
    const path = parseUrlPath(urlValue);
    if (!path) return;
    const normalizedStatus = Number(status) || 0;
    if (normalizedStatus > 0) {
      lastZendeskSessionProbeAt = Date.now();
      lastZendeskSessionStatus = normalizedStatus;
    }
    if (isSessionPath(path)) {
      if (normalizedStatus === 200) {
        emitZendeskSessionOk(payload && typeof payload === "object" ? payload : null, reason || "session_endpoint_200", normalizedStatus);
      } else if (normalizedStatus === 401 || normalizedStatus === 403) {
        emitZendeskLogout(reason || "session_endpoint_unauthorized", normalizedStatus);
      }
      return;
    }
    if (isLikelyLogoutPath(path)) {
      if ((normalizedStatus >= 200 && normalizedStatus < 400) || normalizedStatus === 401 || normalizedStatus === 403) {
        emitZendeskLogout(reason || "logout_path_detected", normalizedStatus || 401);
      }
    }
  }

  function installZendeskNetworkHooks() {
    if (!isZendeskPage() || zendeskNetworkHooksInstalled) return;
    zendeskNetworkHooksInstalled = true;

    try {
      if (typeof window.fetch === "function") {
        const originalFetch = window.fetch.bind(window);
        window.fetch = async function patchedZipFetch(input, init) {
          const response = await originalFetch(input, init);
          try {
            const url = typeof input === "string"
              ? input
              : input && typeof input === "object" && "url" in input
                ? input.url
                : "";
            const status = Number(response && response.status) || 0;
            const path = parseUrlPath(url);
            if (isSessionPath(path) && status === 200) {
              response.clone().json()
                .then((jsonPayload) => {
                  inspectZendeskAuthResponse(url, status, jsonPayload, "fetch_session_200");
                })
                .catch(() => {
                  inspectZendeskAuthResponse(url, status, null, "fetch_session_200");
                });
            } else {
              inspectZendeskAuthResponse(url, status, null, "fetch_observed");
            }
          } catch (_) {}
          return response;
        };
      }
    } catch (_) {}

    try {
      if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype) {
        const originalOpen = XMLHttpRequest.prototype.open;
        const originalSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function patchedZipXhrOpen(method, url) {
          this.__zipAuthUrl = url;
          this.__zipAuthMethod = method;
          return originalOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function patchedZipXhrSend(body) {
          if (!this.__zipAuthListenerInstalled) {
            this.__zipAuthListenerInstalled = true;
            this.addEventListener("loadend", () => {
              try {
                const status = Number(this.status) || 0;
                const url = this.__zipAuthUrl || "";
                let payload = null;
                const path = parseUrlPath(url);
                if (isSessionPath(path)) {
                  payload = parseJsonMaybe(this.responseText || "");
                }
                inspectZendeskAuthResponse(url, status, payload, "xhr_observed");
              } catch (_) {}
            });
          }
          return originalSend.apply(this, [body]);
        };
      }
    } catch (_) {}
  }

  function hasZendeskLoginDomMarkers() {
    if (!isZendeskPage() || typeof document === "undefined") return false;
    const selectors = [
      "form[action*='/access/login']",
      "form[action*='/signin']",
      "input[name='user[email]']",
      "input[name='user[password]']"
    ];
    return selectors.some((selector) => {
      try {
        return !!document.querySelector(selector);
      } catch (_) {
        return false;
      }
    });
  }

  function installZendeskDomObserver() {
    if (!isZendeskPage() || zendeskDomObserverInstalled) return;
    zendeskDomObserverInstalled = true;
    if (typeof MutationObserver !== "function" || typeof document === "undefined") return;
    const root = document.documentElement || document.body;
    if (!root) return;
    const observer = new MutationObserver(() => {
      const path = String(window.location && window.location.pathname ? window.location.pathname : "").toLowerCase();
      if (isLikelyLogoutPath(path) || hasZendeskLoginDomMarkers()) {
        emitZendeskLogout("dom_logout_marker", 401);
        return;
      }
      scheduleZendeskSessionProbe("dom_observer", 350);
    });
    observer.observe(root, { subtree: true, childList: true, attributes: true });
  }

  function installZendeskSessionObservers() {
    if (!isZendeskPage() || zendeskObserversInstalled) return;
    zendeskObserversInstalled = true;
    installZendeskNetworkHooks();
    installZendeskDomObserver();

    const probeIfActive = (reason) => {
      const path = String(window.location && window.location.pathname ? window.location.pathname : "").toLowerCase();
      if (isLikelyLogoutPath(path) || hasZendeskLoginDomMarkers()) {
        emitZendeskLogout(reason || "logout_path_detected", 401);
        return;
      }
      scheduleZendeskSessionProbe(reason || "observer_probe", 50);
    };

    window.addEventListener("focus", () => probeIfActive("focus_probe"));
    window.addEventListener("pageshow", () => probeIfActive("pageshow_probe"));
    window.addEventListener("popstate", () => probeIfActive("popstate_probe"));
    window.addEventListener("hashchange", () => probeIfActive("hashchange_probe"));
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) probeIfActive("visibility_probe");
    });
    probeIfActive("bootstrap_probe");
  }

  function normalizeCustomFieldValue(value) {
    if (value == null) return "";
    if (typeof value === "string") return value.trim();
    if (typeof value === "number" || typeof value === "boolean") return String(value).trim();
    return "";
  }

  function findCustomFieldValue(customFields, fieldId) {
    const target = String(fieldId || "");
    if (!target) return "";
    if (!Array.isArray(customFields)) return "";
    for (const field of customFields) {
      if (!field || typeof field !== "object") continue;
      const id = field.id ?? field.field_id ?? field.custom_field_id;
      if (id == null) continue;
      if (String(id) !== target) continue;
      const value = normalizeCustomFieldValue(field.value ?? field.raw_value ?? field.default_value);
      if (value) return value;
    }
    return "";
  }

  function extractJiraIssueKey(row) {
    if (!row || typeof row !== "object") return "";
    const fromCustomFields = findCustomFieldValue(row.custom_fields, JIRA_ENG_TICKET_FIELD_ID);
    if (fromCustomFields) return fromCustomFields;
    const fields = row.fields;
    if (fields && typeof fields === "object") {
      const direct = fields[JIRA_ENG_TICKET_FIELD_ID] ?? fields[Number(JIRA_ENG_TICKET_FIELD_ID)];
      return normalizeCustomFieldValue(direct);
    }
    return "";
  }

  function buildJiraIssueUrl(issueKey) {
    const key = normalizeCustomFieldValue(issueKey);
    if (!key) return "";
    if (/^https?:\/\//i.test(key)) return key;
    return JIRA_BROWSE_URL_PREFIX + encodeURIComponent(key);
  }

  function normalizeEmailAddress(value) {
    const raw = String(value == null ? "" : value).trim();
    if (!raw) return "";
    const match = raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
    return match ? String(match[0]).toLowerCase() : "";
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll("\"", "&quot;")
      .replaceAll("'", "&#39;");
  }

  function extractTicketAssigneeName(row) {
    const source = row && typeof row === "object" ? row : {};
    const nestedAssignee = source.assignee && typeof source.assignee === "object" ? source.assignee : null;
    const candidates = [
      source.assignee_name,
      source.assigneeName,
      source.owner_name,
      source.ownerName,
      nestedAssignee && nestedAssignee.name,
      nestedAssignee && nestedAssignee.display_name
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const value = String(candidates[i] == null ? "" : candidates[i]).replace(/\s+/g, " ").trim();
      if (value) return value;
    }
    return "";
  }

  function extractTicketRequesterName(row) {
    const source = row && typeof row === "object" ? row : {};
    const nestedRequester = source.requester && typeof source.requester === "object" ? source.requester : null;
    const nestedRequestor = source.requestor && typeof source.requestor === "object" ? source.requestor : null;
    const requesterScalar = normalizeZendeskEntityDisplayText(source.requester);
    const requestorScalar = normalizeZendeskEntityDisplayText(source.requestor);
    const candidates = [
      source.requester_name,
      source.requesterName,
      source.requestor_name,
      source.requestorName,
      nestedRequester && nestedRequester.name,
      nestedRequester && nestedRequester.display_name,
      nestedRequestor && nestedRequestor.name,
      nestedRequestor && nestedRequestor.display_name,
      requesterScalar,
      requestorScalar
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const value = String(candidates[i] == null ? "" : candidates[i]).replace(/\s+/g, " ").trim();
      if (value) return value;
    }
    return "";
  }

  function extractTicketRequesterId(row) {
    const source = row && typeof row === "object" ? row : {};
    const nestedRequester = source.requester && typeof source.requester === "object" ? source.requester : null;
    const nestedRequestor = source.requestor && typeof source.requestor === "object" ? source.requestor : null;
    const requesterScalar = source.requester != null && typeof source.requester !== "object" ? source.requester : "";
    const requestorScalar = source.requestor != null && typeof source.requestor !== "object" ? source.requestor : "";
    const candidates = [
      source.requester_id,
      source.requesterId,
      source.requestor_id,
      source.requestorId,
      nestedRequester && nestedRequester.id,
      nestedRequestor && nestedRequestor.id,
      requesterScalar,
      requestorScalar
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const id = normalizeZendeskEntityId(candidates[i]);
      if (id) return id;
    }
    return "";
  }

  function extractTicketOrganizationId(row) {
    const source = row && typeof row === "object" ? row : {};
    const organization = source.organization && typeof source.organization === "object" ? source.organization : null;
    const organizationScalar = source.organization != null && typeof source.organization !== "object"
      ? source.organization
      : "";
    const candidates = [
      source.organization_id,
      source.organizationId,
      organization && organization.id,
      organizationScalar
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const id = normalizeZendeskEntityId(candidates[i]);
      if (id) return id;
    }
    return "";
  }

  function extractTicketOrganizationName(row) {
    const source = row && typeof row === "object" ? row : {};
    const organization = source.organization && typeof source.organization === "object" ? source.organization : null;
    const organizationScalarName = normalizeZendeskEntityDisplayText(source.organization);
    const candidates = [
      source.organization_name,
      source.organizationName,
      organization && organization.name,
      organizationScalarName
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const name = String(candidates[i] == null ? "" : candidates[i]).replace(/\s+/g, " ").trim();
      if (name) return name;
    }
    return "";
  }

  function buildRequestorAnchor(email, name) {
    const requestorEmail = String(email == null ? "" : email).trim();
    const requestorName = String(name == null ? "" : name).trim();
    if (!requestorEmail && !requestorName) return "";
    const label = escapeHtml(requestorName || requestorEmail);
    if (!requestorEmail) return label;
    return "<a href=\"mailto:" + escapeHtml(requestorEmail) + "\">" + label + "</a>";
  }

  function extractTicketRequesterEmail(row) {
    const source = row && typeof row === "object" ? row : {};
    const nestedRequester = source.requester && typeof source.requester === "object" ? source.requester : null;
    const nestedRequestor = source.requestor && typeof source.requestor === "object" ? source.requestor : null;
    const nestedVia = source.via && typeof source.via === "object" ? source.via : null;
    const viaSource = nestedVia && nestedVia.source && typeof nestedVia.source === "object" ? nestedVia.source : null;
    const viaFrom = viaSource && viaSource.from && typeof viaSource.from === "object" ? viaSource.from : null;
    const requesterScalar = normalizeZendeskEntityDisplayText(source.requester);
    const requestorScalar = normalizeZendeskEntityDisplayText(source.requestor);
    const candidates = [
      source.requester_email,
      source.requesterEmail,
      source.email,
      source.email_address,
      source.recipient_email,
      source.recipient,
      source.via_email,
      nestedRequester && nestedRequester.email,
      nestedRequester && nestedRequester.primary_email,
      nestedRequestor && nestedRequestor.email,
      nestedRequestor && nestedRequestor.primary_email,
      requesterScalar,
      requestorScalar,
      viaFrom && viaFrom.address,
      viaFrom && viaFrom.email
    ];
    for (let i = 0; i < candidates.length; i += 1) {
      const value = normalizeEmailAddress(candidates[i]);
      if (value) return value;
    }
    return "";
  }

  function normalizeTicket(row) {
    const id = row && row.id != null ? row.id : "";
    const jiraIssueKey = extractJiraIssueKey(row);
    const assigneeName = extractTicketAssigneeName(row);
    const requesterName = extractTicketRequesterName(row);
    const requesterEmail = extractTicketRequesterEmail(row);
    const requesterId = extractTicketRequesterId(row);
    const organizationId = extractTicketOrganizationId(row);
    const organizationName = extractTicketOrganizationName(row);
    return {
      id,
      subject: (row && row.subject) || "",
      status: (row && row.status) || "",
      priority: (row && row.priority) || "",
      created_at: (row && row.created_at) || "",
      updated_at: (row && row.updated_at) || "",
      url: id ? TICKET_URL_PREFIX + id : "",
      assignee_name: assigneeName,
      owner_name: assigneeName,
      requester_id: requesterId,
      requester_name: requesterName,
      requester_email: requesterEmail,
      requestor: buildRequestorAnchor(requesterEmail, requesterName),
      requestor_name: requesterName,
      requestor_name_translated: requesterName,
      requestor_email: requesterEmail,
      organization_id: organizationId,
      organization: organizationName,
      organization_name: organizationName,
      organization_name_translated: organizationName,
      jira_issue_key: jiraIssueKey,
      jira_url: buildJiraIssueUrl(jiraIssueKey)
    };
  }

  /** Keep active + solved tickets, but never include closed tickets anywhere in ZIP. */
  const NON_CLOSED_STATUS_QUERY = " status:new status:open status:pending status:hold status:solved";
  const DEFAULT_TICKET_SEARCH_LIMIT = 100;
  const MAX_TICKET_SEARCH_RESULTS = 50000;
  const MAX_TICKET_SEARCH_PER_PAGE = 100;
  const MAX_SEARCH_TICKET_PAGES = 10;
  const MAX_VIEW_TICKET_PAGES = 10;
  const DEFAULT_ZENDESK_SEARCH_CACHE_TTL_SECONDS = 30;
  const DEFAULT_ZENDESK_SEARCH_FALLBACK_THRESHOLD_MS = 1500;
  const DEFAULT_ZENDESK_SEARCH_FIELDS_NEEDED = [
    "id",
    "result_type",
    "subject",
    "status",
    "priority",
    "created_at",
    "updated_at",
    "assignee_id",
    "assignee",
    "requester_id",
    "requestor_id",
    "requester",
    "requestor",
    "organization_id",
    "organization",
    "organization_name",
    "requester_name",
    "requestor_name",
    "requester_email",
    "requestor_email",
    "custom_fields",
    "tags",
    "via"
  ];
  const REQUIRED_TICKET_ENRICHMENT_FIELDS = [
    "id",
    "result_type",
    "requester_id",
    "requestor_id",
    "organization_id",
    "requester",
    "requestor",
    "organization",
    "requester_name",
    "requestor_name",
    "organization_name",
    "requester_email",
    "requestor_email"
  ];
  let zendeskTicketSearchService = null;
  let zendeskTicketSearchServiceConcurrency = 0;

  function isClosedStatus(status) {
    return String(status || "").trim().toLowerCase() === "closed";
  }

  function includeTicketByStatus(row) {
    const status = row && row.status != null ? row.status : "";
    return !isClosedStatus(status);
  }

  function normalizeTicketId(value) {
    if (value == null) return "";
    return String(value).trim();
  }

  function normalizeZendeskEntityId(value) {
    const raw = String(value == null ? "" : value).trim();
    if (!raw) return "";
    return /^\d+$/.test(raw) ? raw : "";
  }

  function normalizeZendeskEntityDisplayText(value) {
    if (value == null || typeof value === "object") return "";
    const raw = String(value).replace(/\s+/g, " ").trim();
    if (!raw) return "";
    return normalizeZendeskEntityId(raw) ? "" : raw;
  }

  function normalizeSearchLimit(value, fallback, maxValue) {
    const maxNum = Number(maxValue);
    const hardMax = Number.isFinite(maxNum) && maxNum > 0
      ? Math.trunc(maxNum)
      : MAX_TICKET_SEARCH_RESULTS;
    const fallbackNum = Number(fallback);
    const fallbackLimit = Number.isFinite(fallbackNum)
      ? (fallbackNum > 0 ? Math.min(hardMax, Math.trunc(fallbackNum)) : 0)
      : DEFAULT_TICKET_SEARCH_LIMIT;
    const num = Number(value);
    if (!Number.isFinite(num) || num <= 0) return fallbackLimit;
    return Math.min(hardMax, Math.trunc(num));
  }

  function buildTicketOnlySearchQuery(rawQuery) {
    const query = String(rawQuery == null ? "" : rawQuery).replace(/\s+/g, " ").trim();
    if (!query) return "";
    if (/\btype\s*:\s*ticket\b/i.test(query)) return query;
    return "type:ticket " + query;
  }

  function isScopedTicketSearchQuery(rawQuery) {
    const query = String(rawQuery == null ? "" : rawQuery).trim();
    if (!query) return false;
    return /\b(?:assignee_id|organization_id|group_id|requester_id)\s*:/i.test(query)
      || /\bid\s*:\s*\d+\b/i.test(query);
  }

  function getZendeskTicketSearchModule() {
    try {
      if (typeof globalThis !== "undefined" && globalThis && globalThis.ZIP_ZENDESK_TICKET_SEARCH) {
        return globalThis.ZIP_ZENDESK_TICKET_SEARCH;
      }
    } catch (_) {}
    try {
      if (typeof window !== "undefined" && window && window.ZIP_ZENDESK_TICKET_SEARCH) {
        return window.ZIP_ZENDESK_TICKET_SEARCH;
      }
    } catch (_) {}
    return null;
  }

  function logZendeskSearchEvent(payload) {
    const event = payload && typeof payload === "object" ? payload : {};
    try {
      sendRuntimeMessage({
        type: "ZIP_ZENDESK_SEARCH_METRICS",
        payload: {
          ...event,
          ts: Date.now()
        }
      });
    } catch (_) {}
    try {
      if (event && event.type) {
        console.debug("[ZIP] Zendesk search:", event.type, event);
      }
    } catch (_) {}
  }

  function createZendeskSearchFetchImpl() {
    return function zendeskSearchFetch(url, init) {
      return fetch(url, {
        method: "GET",
        cache: "no-store",
        credentials: "include",
        headers: {
          Accept: "application/json",
          ...(init && init.headers && typeof init.headers === "object" ? init.headers : {})
        },
        ...(init && typeof init === "object" ? init : {})
      });
    };
  }

  function getZendeskTicketSearchService(options) {
    const opts = options && typeof options === "object" ? options : {};
    const requestedConcurrency = normalizeSearchLimit(opts.concurrency, 4, 16);
    if (zendeskTicketSearchService && zendeskTicketSearchServiceConcurrency === requestedConcurrency) {
      return zendeskTicketSearchService;
    }
    const mod = getZendeskTicketSearchModule();
    if (!mod || typeof mod.createZendeskTicketSearchService !== "function") return null;
    zendeskTicketSearchService = mod.createZendeskTicketSearchService({
      baseUrl: BASE,
      authScope: BASE,
      fetchImpl: createZendeskSearchFetchImpl(),
      concurrency: requestedConcurrency,
      defaultDateRangeDays: 90,
      logger: logZendeskSearchEvent
    });
    zendeskTicketSearchServiceConcurrency = requestedConcurrency;
    return zendeskTicketSearchService;
  }

  function resolveZendeskSearchFields(options) {
    const opts = options && typeof options === "object" ? options : {};
    const fields = Array.isArray(opts.fieldsNeeded) && opts.fieldsNeeded.length
      ? opts.fieldsNeeded
      : DEFAULT_ZENDESK_SEARCH_FIELDS_NEEDED;
    const normalized = fields
      .map((field) => String(field || "").trim())
      .filter(Boolean);
    const out = [];
    const seen = new Set();
    const addField = (fieldName) => {
      const key = String(fieldName || "").trim();
      if (!key || seen.has(key)) return;
      seen.add(key);
      out.push(key);
    };
    normalized.forEach(addField);
    REQUIRED_TICKET_ENRICHMENT_FIELDS.forEach(addField);
    return out;
  }

  function isInactiveOrHiddenEntity(entity) {
    if (!entity || typeof entity !== "object") return false;
    if (entity.active === false || entity.is_active === false) return true;
    if (entity.deleted === true || entity.is_deleted === true) return true;
    if (entity.suspended === true || entity.is_suspended === true) return true;
    if (entity.hidden === true || entity.is_hidden === true) return true;
    if (entity.deleted_at != null) return true;
    return false;
  }

  function readStorageLocal(keys) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome === "undefined" || !chrome || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== "function") {
          resolve({});
          return;
        }
        chrome.storage.local.get(keys, (items) => {
          const runtime = getChromeRuntime();
          if (runtime && runtime.lastError) {
            resolve({});
            return;
          }
          resolve(items && typeof items === "object" ? items : {});
        });
      } catch (_) {
        resolve({});
      }
    });
  }

  function getTicketEnrichmentModule() {
    const mod = typeof globalThis !== "undefined"
      ? globalThis.ZipTicketEnrichment
      : (typeof window !== "undefined" ? window.ZipTicketEnrichment : null);
    if (!mod || typeof mod !== "object") return null;
    if (typeof mod.enrichTicketsWithRequestorOrg !== "function") return null;
    if (typeof mod.createTranslationCache !== "function") return null;
    if (typeof mod.createTranslatorAdapter !== "function") return null;
    return mod;
  }

  function resolveTicketLocale(options) {
    const opts = options && typeof options === "object" ? options : {};
    const explicit = String(
      opts.locale
      || opts.targetLocale
      || opts.agentLocale
      || opts.userLocale
      || ""
    ).trim();
    if (explicit) return explicit;
    if (typeof navigator !== "undefined" && navigator.language) {
      return String(navigator.language).trim() || "en-US";
    }
    return "en-US";
  }

  async function isRequestorOrgEnrichmentEnabled(options) {
    const opts = options && typeof options === "object" ? options : {};
    if (typeof opts.enabled === "boolean") return opts.enabled;
    const now = Date.now();
    if (
      requestorOrgFeatureFlagCache.loaded
      && now - Number(requestorOrgFeatureFlagCache.loadedAt || 0) < REQUESTOR_ORG_ENRICHMENT_FLAG_CACHE_TTL_MS
    ) {
      return requestorOrgFeatureFlagCache.value !== false;
    }
    let enabled = true;
    try {
      const stored = await readStorageLocal([REQUESTOR_ORG_ENRICHMENT_FLAG_STORAGE_KEY, "zip_feature_flags"]);
      const explicit = stored && Object.prototype.hasOwnProperty.call(stored, REQUESTOR_ORG_ENRICHMENT_FLAG_STORAGE_KEY)
        ? stored[REQUESTOR_ORG_ENRICHMENT_FLAG_STORAGE_KEY]
        : undefined;
      if (typeof explicit === "boolean") {
        enabled = explicit;
      } else if (stored && stored.zip_feature_flags && typeof stored.zip_feature_flags === "object") {
        const flags = stored.zip_feature_flags;
        if (typeof flags.requestorOrgEnrichment === "boolean") {
          enabled = flags.requestorOrgEnrichment;
        }
      }
    } catch (_) {}
    requestorOrgFeatureFlagCache = {
      loaded: true,
      loadedAt: now,
      value: enabled
    };
    return enabled;
  }

  function getConfiguredTranslationBatchProvider() {
    if (typeof window === "undefined") return null;
    try {
      if (typeof window.ZIP_TRANSLATE_BATCH === "function") {
        return window.ZIP_TRANSLATE_BATCH.bind(window);
      }
    } catch (_) {}
    try {
      if (window.ZIP_TRANSLATOR_ADAPTER && typeof window.ZIP_TRANSLATOR_ADAPTER.translateBatch === "function") {
        return (sourceStrings, translationOptions) => window.ZIP_TRANSLATOR_ADAPTER.translateBatch(sourceStrings, translationOptions);
      }
    } catch (_) {}
    return null;
  }

  function getRequestorOrgTranslationCache(moduleApi) {
    if (requestorOrgTranslationCache) return requestorOrgTranslationCache;
    requestorOrgTranslationCache = moduleApi.createTranslationCache({
      ttlMs: REQUESTOR_ORG_TRANSLATION_CACHE_TTL_MS
    });
    return requestorOrgTranslationCache;
  }

  function getRequestorOrgTranslator(moduleApi) {
    if (requestorOrgTranslatorAdapter) return requestorOrgTranslatorAdapter;
    const provider = getConfiguredTranslationBatchProvider();
    requestorOrgTranslatorAdapter = moduleApi.createTranslatorAdapter({
      translateBatch: async (sourceStrings, translationOptions) => {
        if (!provider) return sourceStrings;
        try {
          return await provider(sourceStrings, translationOptions);
        } catch (_) {
          return sourceStrings;
        }
      }
    });
    return requestorOrgTranslatorAdapter;
  }

  function buildFallbackRequestorOrgTicket(row) {
    const ticket = row && typeof row === "object" ? row : {};
    const requestorName = String(
      ticket.requestor_name_translated
      || ticket.requestor_name
      || ticket.requester_name
      || ticket.requesterName
      || ""
    ).replace(/\s+/g, " ").trim();
    const requestorEmail = normalizeEmailAddress(
      ticket.requestor_email
      || ticket.requester_email
      || ticket.requesterEmail
      || ""
    );
    const organizationName = String(
      ticket.organization_name_translated
      || ticket.organization_name
      || ticket.organizationName
      || ticket.organization
      || ""
    ).replace(/\s+/g, " ").trim();
    return {
      ...ticket,
      requestor: buildRequestorAnchor(requestorEmail, requestorName),
      requestor_name: requestorName,
      requestor_name_translated: requestorName,
      requestor_email: requestorEmail,
      requester_name: requestorName || ticket.requester_name || "",
      requester_email: requestorEmail || ticket.requester_email || "",
      organization: organizationName,
      organization_name: organizationName,
      organization_name_translated: organizationName
    };
  }

  function ticketNeedsRequestorOrgHydration(row) {
    const ticket = row && typeof row === "object" ? row : {};
    const requestorName = extractTicketRequesterName(ticket);
    const organizationName = extractTicketOrganizationName(ticket);
    const requesterId = extractTicketRequesterId(ticket);
    const organizationId = extractTicketOrganizationId(ticket);
    if (!requestorName && requesterId) return true;
    if (!organizationName && organizationId) return true;
    return false;
  }

  function recordRequestorOrgMetrics(source, metrics) {
    const entry = {
      at: new Date().toISOString(),
      source: String(source || "unknown"),
      metrics: metrics && typeof metrics === "object" ? metrics : {}
    };
    requestorOrgMetricsHistory.push(entry);
    while (requestorOrgMetricsHistory.length > REQUESTOR_ORG_METRICS_HISTORY_LIMIT) {
      requestorOrgMetricsHistory.shift();
    }
    try {
      if (typeof window !== "undefined") {
        window.__ZIP_REQUESTOR_ORG_METRICS__ = requestorOrgMetricsHistory.slice();
      }
    } catch (_) {}
    try {
      sendRuntimeMessage({
        type: "ZIP_TICKET_ENRICHMENT_METRICS",
        payload: entry
      });
    } catch (_) {}
  }

  async function enrichTicketsWithRequestorOrg(tickets, options) {
    const rows = Array.isArray(tickets) ? tickets : [];
    if (!rows.length) {
      return { tickets: [], metrics: { ticketCount: 0, featureFlagEnabled: true } };
    }

    const opts = options && typeof options === "object" ? options : {};
    const source = String(opts.source || "tickets").trim() || "tickets";
    const enabled = await isRequestorOrgEnrichmentEnabled(opts);
    const forceHydration = !enabled && rows.some((row) => ticketNeedsRequestorOrgHydration(row));
    const shouldRunEnrichment = enabled || forceHydration;
    if (!shouldRunEnrichment) {
      const fallbackRows = rows.map((row) => buildFallbackRequestorOrgTicket(row));
      const disabledMetrics = {
        ticketCount: fallbackRows.length,
        featureFlagEnabled: false,
        forceHydration: false
      };
      recordRequestorOrgMetrics(source, disabledMetrics);
      return { tickets: fallbackRows, metrics: disabledMetrics };
    }

    const moduleApi = getTicketEnrichmentModule();
    if (!moduleApi) {
      const fallbackRows = rows.map((row) => buildFallbackRequestorOrgTicket(row));
      const missingModuleMetrics = {
        ticketCount: fallbackRows.length,
        featureFlagEnabled: enabled,
        forceHydration,
        moduleMissing: true
      };
      recordRequestorOrgMetrics(source, missingModuleMetrics);
      return { tickets: fallbackRows, metrics: missingModuleMetrics };
    }

    try {
      const enriched = await moduleApi.enrichTicketsWithRequestorOrg(rows, {
        baseUrl: BASE,
        fetchJson,
        targetLocale: resolveTicketLocale(opts),
        translationCache: getRequestorOrgTranslationCache(moduleApi),
        translator: getRequestorOrgTranslator(moduleApi)
      });
      const outputRows = Array.isArray(enriched && enriched.tickets)
        ? enriched.tickets.map((row) => buildFallbackRequestorOrgTicket(row))
        : rows.map((row) => buildFallbackRequestorOrgTicket(row));
      const metrics = {
        ...(enriched && enriched.metrics && typeof enriched.metrics === "object" ? enriched.metrics : {}),
        ticketCount: outputRows.length,
        featureFlagEnabled: enabled,
        forceHydration,
        targetLocale: resolveTicketLocale(opts)
      };
      recordRequestorOrgMetrics(source, metrics);
      return { tickets: outputRows, metrics };
    } catch (error) {
      const fallbackRows = rows.map((row) => buildFallbackRequestorOrgTicket(row));
      const failedMetrics = {
        ticketCount: fallbackRows.length,
        featureFlagEnabled: enabled,
        forceHydration,
        error: error && error.message ? error.message : "enrichment_failed"
      };
      recordRequestorOrgMetrics(source, failedMetrics);
      return { tickets: fallbackRows, metrics: failedMetrics };
    }
  }

  async function loadTickets(userId, options) {
    const assigneeId = String(userId || "").trim();
    if (!assigneeId) return { tickets: [] };
    return loadTicketsByAssigneeId(assigneeId, {
      ...(options && typeof options === "object" ? options : {}),
      source: "loadTickets"
    });
  }

  async function loadTicketsByOrg(orgId, options) {
    if (!orgId) return { tickets: [] };
    const query = "type:ticket organization_id:" + orgId + NON_CLOSED_STATUS_QUERY;
    return searchTickets(query, {
      ...(options && typeof options === "object" ? options : {}),
      defaultDateRangeDays: 0,
      source: "loadTicketsByOrg"
    });
  }

  async function loadTicketsBySearchQuery(rawQuery, options) {
    const query = String(rawQuery == null ? "" : rawQuery).replace(/\s+/g, " ").trim();
    if (!query) return { tickets: [] };
    const opts = options && typeof options === "object" ? options : {};
    const preserveNativeSearchResults = Object.prototype.hasOwnProperty.call(opts, "preserveNativeSearchResults")
      ? !!opts.preserveNativeSearchResults
      : true;
    return searchTickets(query, {
      ...opts,
      preserveNativeSearchResults,
      maxResults: normalizeSearchLimit(
        Object.prototype.hasOwnProperty.call(opts, "maxResults") ? opts.maxResults : opts.limit,
        DEFAULT_TICKET_SEARCH_LIMIT,
        MAX_TICKET_SEARCH_RESULTS
      ),
      pageSize: normalizeSearchLimit(
        Object.prototype.hasOwnProperty.call(opts, "pageSize") ? opts.pageSize : opts.perPage,
        MAX_TICKET_SEARCH_PER_PAGE,
        MAX_TICKET_SEARCH_PER_PAGE
      ),
      source: "loadTicketsBySearchQuery"
    });
  }

  async function searchTickets(query, options) {
    const opts = options && typeof options === "object" ? options : {};
    const preserveNativeSearchResults = !!opts.preserveNativeSearchResults;
    const limit = normalizeSearchLimit(
      Object.prototype.hasOwnProperty.call(opts, "maxResults") ? opts.maxResults : opts.limit,
      DEFAULT_TICKET_SEARCH_LIMIT,
      MAX_TICKET_SEARCH_RESULTS
    );
    const pageSize = normalizeSearchLimit(
      Object.prototype.hasOwnProperty.call(opts, "pageSize") ? opts.pageSize : opts.perPage,
      MAX_TICKET_SEARCH_PER_PAGE,
      MAX_TICKET_SEARCH_PER_PAGE
    );
    const useModernSearchService = opts.useModernSearchService === true;
    if (!useModernSearchService) {
      return searchTicketsLegacyOffset(query, {
        ...opts,
        limit,
        perPage: pageSize
      });
    }
    const searchService = getZendeskTicketSearchService(opts);
    if (!searchService || typeof searchService.searchTickets !== "function") {
      return searchTicketsLegacyOffset(query, {
        ...opts,
        limit,
        perPage: pageSize
      });
    }

    const searchResult = await searchService.searchTickets(query, {
      maxResults: limit,
      pageSize,
      fieldsNeeded: resolveZendeskSearchFields(opts),
      useIncremental: !!opts.useIncremental,
      sync: !!opts.sync,
      cacheTTL: Object.prototype.hasOwnProperty.call(opts, "cacheTTL")
        ? opts.cacheTTL
        : DEFAULT_ZENDESK_SEARCH_CACHE_TTL_SECONDS,
      fallbackThreshold: Object.prototype.hasOwnProperty.call(opts, "fallbackThreshold")
        ? opts.fallbackThreshold
        : DEFAULT_ZENDESK_SEARCH_FALLBACK_THRESHOLD_MS,
      debug: !!opts.debug,
      requireWildcardOptIn: !!opts.requireWildcardOptIn,
      allowBroadWildcard: !!opts.allowBroadWildcard,
      defaultDateRangeDays: Object.prototype.hasOwnProperty.call(opts, "defaultDateRangeDays")
        ? opts.defaultDateRangeDays
        : 90,
      statusFilters: Array.isArray(opts.statusFilters) && opts.statusFilters.length
        ? opts.statusFilters
        : ["new", "open", "pending", "hold", "solved"],
      requiredTags: Array.isArray(opts.requiredTags) ? opts.requiredTags : [],
      syncThreshold: Object.prototype.hasOwnProperty.call(opts, "syncThreshold") ? opts.syncThreshold : 10000,
      sortBy: opts.sortBy,
      sortOrder: opts.sortOrder
    });

    if (searchResult && searchResult.error) {
      const fallbackResult = await searchTicketsLegacyOffset(query, {
        ...opts,
        limit,
        perPage: pageSize
      });
      return {
        ...(fallbackResult && typeof fallbackResult === "object" ? fallbackResult : { tickets: [] }),
        metrics: {
          ...(searchResult.metrics && typeof searchResult.metrics === "object" ? searchResult.metrics : {}),
          ...(fallbackResult && fallbackResult.metrics && typeof fallbackResult.metrics === "object" ? fallbackResult.metrics : {}),
          fallbackReason: "search_service_error",
          fallbackError: searchResult.error
        }
      };
    }

    const sourceRows = Array.isArray(searchResult && searchResult.tickets) ? searchResult.tickets : [];
    if (!sourceRows.length && isScopedTicketSearchQuery(query)) {
      const fallbackResult = await searchTicketsLegacyOffset(query, {
        ...opts,
        limit,
        perPage: pageSize
      });
      return {
        ...(fallbackResult && typeof fallbackResult === "object" ? fallbackResult : { tickets: [] }),
        metrics: {
          ...(searchResult && searchResult.metrics && typeof searchResult.metrics === "object" ? searchResult.metrics : {}),
          ...(fallbackResult && fallbackResult.metrics && typeof fallbackResult.metrics === "object" ? fallbackResult.metrics : {}),
          fallbackReason: "scoped_query_empty"
        }
      };
    }
    const all = [];
    const seenTicketIds = new Set();
    for (let i = 0; i < sourceRows.length; i += 1) {
      const raw = sourceRows[i];
      const type = String((raw && raw.result_type) || "").toLowerCase();
      if (type && type !== "ticket") continue;
      if (!preserveNativeSearchResults && !includeTicketByStatus(raw)) continue;
      const normalized = normalizeTicket(raw || {});
      const ticketId = normalizeTicketId(normalized.id);
      if (!ticketId || seenTicketIds.has(ticketId)) continue;
      seenTicketIds.add(ticketId);
      all.push(normalized);
      if (limit > 0 && all.length >= limit) break;
    }
    const rowsToEnrich = limit > 0 ? all.slice(0, limit) : all;
    const enriched = await enrichTicketsWithRequestorOrg(rowsToEnrich, {
      ...opts,
      source: "searchTickets"
    });
    return {
      tickets: enriched.tickets,
      metrics: {
        ...(searchResult && searchResult.metrics && typeof searchResult.metrics === "object"
          ? searchResult.metrics
          : {}),
        ...(enriched && enriched.metrics && typeof enriched.metrics === "object"
          ? enriched.metrics
          : {})
      }
    };
  }

  async function searchTicketsLegacyOffset(query, options) {
    const opts = options && typeof options === "object" ? options : {};
    const preserveNativeSearchResults = !!opts.preserveNativeSearchResults;
    const limit = normalizeSearchLimit(opts.limit, 0, MAX_TICKET_SEARCH_RESULTS);
    const perPage = normalizeSearchLimit(
      opts.perPage,
      limit > 0 ? Math.min(limit, MAX_TICKET_SEARCH_PER_PAGE) : MAX_TICKET_SEARCH_PER_PAGE,
      MAX_TICKET_SEARCH_PER_PAGE
    );
    const sortBy = String(opts.sortBy || "").trim();
    const sortOrder = String(opts.sortOrder || "").trim();
    const params = new URLSearchParams();
    params.set("query", buildTicketOnlySearchQuery(query));
    if (sortBy) params.set("sort_by", sortBy);
    if (sortOrder) params.set("sort_order", sortOrder);
    if (perPage > 0) params.set("per_page", String(perPage));

    let nextUrl = BASE + "/api/v2/search.json?" + params.toString();
    const all = [];
    const seenTicketIds = new Set();
    let pages = 0;
    const maxPages = MAX_SEARCH_TICKET_PAGES;
    while (nextUrl && pages < maxPages) {
      pages += 1;
      const res = await fetchJson(nextUrl);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", tickets: [] };
      }
      if (!res.ok || !res.payload) {
        return { error: "Ticket search failed (HTTP " + res.status + ")", tickets: [] };
      }
      const rows = Array.isArray(res.payload.results) ? res.payload.results : [];
      for (let i = 0; i < rows.length; i += 1) {
        const raw = rows[i];
        const type = String((raw && raw.result_type) || "").toLowerCase();
        if (type && type !== "ticket") continue;
        if (!preserveNativeSearchResults && !includeTicketByStatus(raw)) continue;
        const normalized = normalizeTicket(raw || {});
        const ticketId = normalizeTicketId(normalized.id);
        if (!ticketId || seenTicketIds.has(ticketId)) continue;
        seenTicketIds.add(ticketId);
        all.push(normalized);
        if (limit > 0 && all.length >= limit) break;
      }
      if (limit > 0 && all.length >= limit) break;
      nextUrl = res.payload.next_page || null;
    }
    const rowsToEnrich = limit > 0 ? all.slice(0, limit) : all;
    const enriched = await enrichTicketsWithRequestorOrg(rowsToEnrich, {
      ...opts,
      source: "searchTickets"
    });
    return { tickets: enriched.tickets, metrics: enriched.metrics };
  }

  function parseSearchCount(payload) {
    if (!payload || typeof payload !== "object") return null;
    const container = (payload.count && typeof payload.count === "object")
      ? payload.count
      : payload;
    const raw = container.value != null
      ? container.value
      : container.count != null
        ? container.count
        : container.total;
    if (raw == null) return null;
    const num = Number(raw);
    if (!Number.isFinite(num)) return null;
    return Math.max(0, Math.trunc(num));
  }

  async function searchTicketsCount(query) {
    const url = BASE + "/api/v2/search/count.json?query=" + encodeURIComponent(query);
    const res = await fetchJson(url);
    if (res.status === 401 || res.status === 403) {
      return { error: "Session expired", count: 0 };
    }
    if (!res.ok || !res.payload) {
      return { error: "Search count failed (HTTP " + res.status + ")", count: 0 };
    }
    const count = parseSearchCount(res.payload);
    return { count: count == null ? 0 : count };
  }

  async function loadOrganizations() {
    const list = [];
    const seen = new Set();
    let nextUrl = BASE + "/api/v2/organizations.json";
    let pages = 0;
    const maxPages = 10;
    while (nextUrl && pages < maxPages) {
      pages += 1;
      const res = await fetchJson(nextUrl);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", organizations: [] };
      }
      if (!res.ok || !res.payload) {
        return { error: "Organizations failed (HTTP " + res.status + ")", organizations: [] };
      }
      const orgs = Array.isArray(res.payload.organizations) ? res.payload.organizations : [];
      orgs.forEach((o) => {
        if (!o || o.id == null || isInactiveOrHiddenEntity(o)) return;
        const id = String(o.id);
        if (seen.has(id)) return;
        seen.add(id);
        list.push({ id, name: (o.name || "").trim() || "Org " + o.id });
      });
      nextUrl = res.payload.next_page || null;
    }
    list.sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" }));
    return { organizations: list };
  }

  async function loadViews() {
    const list = [];
    const seen = new Set();
    let nextUrl = BASE + "/api/v2/views.json?active=true";
    let pages = 0;
    const maxPages = 15;
    while (nextUrl && pages < maxPages) {
      pages += 1;
      const res = await fetchJson(nextUrl);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", views: [] };
      }
      if (!res.ok || !res.payload) {
        return { error: "Views failed (HTTP " + res.status + ")", views: [] };
      }
      const views = Array.isArray(res.payload.views) ? res.payload.views : [];
      views.forEach((v) => {
        if (!v || v.id == null || isInactiveOrHiddenEntity(v)) return;
        const id = String(v.id);
        if (seen.has(id)) return;
        seen.add(id);
        list.push({ id, title: (v.title || "").trim() || "View " + v.id });
      });
      nextUrl = res.payload.next_page || null;
    }
    list.sort((a, b) => String(a.title).localeCompare(String(b.title), undefined, { sensitivity: "base" }));
    return { views: list };
  }

  function parseViewCount(payload) {
    if (!payload || typeof payload !== "object") return null;
    const container = (payload.view_count && typeof payload.view_count === "object")
      ? payload.view_count
      : payload;
    const raw = container.value != null ? container.value : container.count;
    if (raw == null) return null;
    const num = Number(raw);
    if (!Number.isFinite(num)) return null;
    return Math.max(0, Math.trunc(num));
  }

  function parseViewCountsMany(payload) {
    const countsById = Object.create(null);
    if (!payload || typeof payload !== "object") return countsById;
    const rows = Array.isArray(payload.view_counts)
      ? payload.view_counts
      : Array.isArray(payload.counts)
        ? payload.counts
        : Array.isArray(payload.views)
          ? payload.views
          : [];
    rows.forEach((row) => {
      if (!row || typeof row !== "object") return;
      const idRaw = row.id ?? row.view_id ?? (row.view && row.view.id);
      if (idRaw == null) return;
      const id = String(idRaw);
      const raw = row.value != null
        ? row.value
        : row.count != null
          ? row.count
          : row.ticket_count != null
            ? row.ticket_count
            : row.total;
      const count = Number(raw);
      if (!Number.isFinite(count)) return;
      countsById[id] = Math.max(0, Math.trunc(count));
    });
    return countsById;
  }

  async function loadViewCount(viewId) {
    if (!viewId) return { viewId: "", count: null };
    const id = String(viewId);
    const url = BASE + "/api/v2/views/" + encodeURIComponent(id) + "/count.json";
    const res = await fetchJson(url);
    if (res.status === 401 || res.status === 403) {
      return { viewId: id, error: "Session expired", count: null };
    }
    if (!res.ok || !res.payload) {
      return { viewId: id, error: "View count failed (HTTP " + res.status + ")", count: null };
    }
    return { viewId: id, count: parseViewCount(res.payload) };
  }

  async function loadViewCountsMany(viewIds) {
    const ids = (Array.isArray(viewIds) ? viewIds : [])
      .map((id) => String(id || "").trim())
      .filter(Boolean);
    if (!ids.length) return { countsById: {} };
    const uniqueIds = Array.from(new Set(ids));
    const chunkSize = 100;
    const allCounts = Object.create(null);
    for (let i = 0; i < uniqueIds.length; i += chunkSize) {
      const chunk = uniqueIds.slice(i, i + chunkSize);
      const url = BASE + "/api/v2/views/count_many.json?ids=" + encodeURIComponent(chunk.join(","));
      const res = await fetchJson(url);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", countsById: allCounts };
      }
      if (!res.ok || !res.payload) {
        return { error: "View counts failed (HTTP " + res.status + ")", countsById: allCounts };
      }
      const parsed = parseViewCountsMany(res.payload);
      chunk.forEach((id) => {
        allCounts[id] = parsed[id] != null ? parsed[id] : 0;
      });
    }
    return { countsById: allCounts };
  }

  async function loadOrganizationCount(orgId) {
    if (!orgId) return { orgId: "", count: null };
    const id = String(orgId);
    const query = "type:ticket organization_id:" + id + NON_CLOSED_STATUS_QUERY;
    const result = await searchTicketsCount(query);
    return { orgId: id, count: result.count || 0, error: result.error };
  }

  async function loadTicketsByView(viewId, options) {
    if (!viewId) return { tickets: [] };
    const all = [];
    const seenTicketIds = new Set();
    let nextUrl = BASE + "/api/v2/views/" + encodeURIComponent(viewId) + "/tickets.json";
    let pages = 0;
    const maxPages = MAX_VIEW_TICKET_PAGES;
    while (nextUrl && pages < maxPages) {
      pages += 1;
      const res = await fetchJson(nextUrl);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", tickets: [] };
      }
      if (!res.ok || !res.payload) {
        return { error: "View tickets failed (HTTP " + res.status + ")", tickets: [] };
      }
      const rows = Array.isArray(res.payload.tickets) ? res.payload.tickets : [];
      rows.forEach((row) => {
        if (!includeTicketByStatus(row)) return;
        const normalized = normalizeTicket(row || {});
        const ticketId = normalizeTicketId(normalized.id);
        if (!ticketId || seenTicketIds.has(ticketId)) return;
        seenTicketIds.add(ticketId);
        all.push(normalized);
      });
      nextUrl = res.payload.next_page || null;
    }
    const enriched = await enrichTicketsWithRequestorOrg(all, {
      ...(options && typeof options === "object" ? options : {}),
      source: "loadTicketsByView"
    });
    return { tickets: enriched.tickets, metrics: enriched.metrics };
  }

  /** GET /api/v2/groups/assignable – list all assignable groups (for By Group dropdown). */
  async function loadAssignableGroups() {
    const list = [];
    const seen = new Set();
    let nextUrl = BASE + "/api/v2/groups/assignable.json?exclude_deleted=true";
    let pages = 0;
    const maxPages = 20;
    while (nextUrl && pages < maxPages) {
      pages += 1;
      const res = await fetchJson(nextUrl);
      if (res.status === 401 || res.status === 403) {
        return { error: "Session expired", groups: [] };
      }
      if (!res.ok || !res.payload) {
        return { error: "Assignable groups failed (HTTP " + res.status + ")", groups: [] };
      }
      const raw = res.payload.groups || [];
      (Array.isArray(raw) ? raw : []).forEach((g) => {
        if (!g || g.id == null || isInactiveOrHiddenEntity(g)) return;
        const id = String(g.id);
        if (seen.has(id)) return;
        seen.add(id);
        list.push({ id, name: (g.name || "").trim() || "Group " + g.id });
      });
      nextUrl = res.payload.next_page || null;
    }
    list.sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" }));
    return { groups: list };
  }

  /** GET /api/lotus/assignables/groups/{group_id}/agents.json – agents in one group. */
  async function loadGroupAgents(groupId) {
    if (!groupId) return { agents: [] };
    const url = BASE + "/api/lotus/assignables/groups/" + encodeURIComponent(String(groupId)) + "/agents.json";
    const res = await fetchJson(url);
    if (res.status === 401 || res.status === 403) {
      return { error: "Session expired", agents: [] };
    }
    if (!res.ok || !res.payload) {
      return { error: "Group agents failed (HTTP " + res.status + ")", agents: [] };
    }
    const raw = res.payload.agents || res.payload.assignable_agents || res.payload.users || [];
    const list = Array.isArray(raw) ? raw : [];
    const agents = [];
    const seen = new Set();
    list.forEach((a) => {
      if (!a) return;
      const id = a.id ?? a.user_id ?? a.agent_id;
      if (id == null) return;
      const user = a.user && typeof a.user === "object" ? a.user : null;
      if (isInactiveOrHiddenEntity(a) || isInactiveOrHiddenEntity(user)) return;
      const sid = String(id);
      if (seen.has(sid)) return;
      seen.add(sid);
      const name = (a.name || a.display_name || (a.user && a.user.name) || "").trim() || "Agent " + id;
      agents.push({ id: sid, name });
    });
    agents.sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" }));
    return { agents };
  }

  /** All assignable groups + members for each. Dataset 1: groups. Dataset 2: agents per group. */
  async function loadAllGroupsWithMembers() {
    const groupsRes = await loadAssignableGroups();
    if (groupsRes.error || !groupsRes.groups || !groupsRes.groups.length) {
      return { error: groupsRes.error || "No groups", groupsWithMembers: [] };
    }
    const groups = groupsRes.groups.slice();
    const groupsWithMembers = new Array(groups.length);
    const maxConcurrent = 8;
    let nextIndex = 0;
    const worker = async () => {
      while (nextIndex < groups.length) {
        const idx = nextIndex;
        nextIndex += 1;
        const group = groups[idx];
        const agentsRes = await loadGroupAgents(group.id);
        const agents = agentsRes.agents || [];
        groupsWithMembers[idx] = { group: { id: group.id, name: group.name }, agents };
      }
    };
    const workers = [];
    for (let i = 0; i < Math.min(maxConcurrent, groups.length); i += 1) workers.push(worker());
    await Promise.all(workers);
    return { groupsWithMembers };
  }

  /** Search API: tickets in group (assignee group), with closed excluded. */
  async function loadTicketsByGroupId(groupId, options) {
    if (!groupId) return { tickets: [] };
    const query = "type:ticket group_id:" + String(groupId) + NON_CLOSED_STATUS_QUERY;
    return searchTickets(query, {
      ...(options && typeof options === "object" ? options : {}),
      defaultDateRangeDays: 0,
      source: "loadTicketsByGroupId"
    });
  }

  async function loadGroupTicketCount(groupId) {
    if (!groupId) return { groupId: "", count: 0 };
    const id = String(groupId);
    const query = "type:ticket group_id:" + id + NON_CLOSED_STATUS_QUERY;
    const result = await searchTicketsCount(query);
    return { groupId: id, count: result.count || 0, error: result.error };
  }

  /** Search API: tickets by assignee_id (closed excluded). Replaces /users/{id}/tickets/assigned. */
  async function loadTicketsByAssigneeId(userId, options) {
    if (!userId) return { tickets: [] };
    const query = "type:ticket assignee_id:" + String(userId) + NON_CLOSED_STATUS_QUERY;
    return searchTickets(query, {
      ...(options && typeof options === "object" ? options : {}),
      defaultDateRangeDays: 0,
      source: "loadTicketsByAssigneeId"
    });
  }

  async function loadAssigneeTicketCount(userId) {
    if (!userId) return { userId: "", count: 0 };
    const id = String(userId);
    const query = "type:ticket assignee_id:" + id + NON_CLOSED_STATUS_QUERY;
    const result = await searchTicketsCount(query);
    return { userId: id, count: result.count || 0, error: result.error };
  }

  function isSlackHostname(hostname) {
    const value = String(hostname || "").trim().toLowerCase();
    return value === "slack.com" || value.endsWith(".slack.com");
  }

  function isSlackWorkspaceHostname(hostname) {
    const value = String(hostname || "").trim().toLowerCase();
    return value.endsWith(".slack.com");
  }

  function isSlackAuthPath(pathname) {
    const path = String(pathname || "").trim().toLowerCase();
    if (!path) return false;
    return path.startsWith("/openid/")
      || path.startsWith("/signin")
      || path.startsWith("/oauth/")
      || path.startsWith("/auth/")
      || path.includes("/ssb/redirect");
  }

  function isSlackPage() {
    return typeof window !== "undefined"
      && window.location
      && isSlackWorkspaceHostname(window.location.hostname)
      && !isSlackAuthPath(window.location.pathname);
  }

  function normalizeSlackWorkspaceOrigin(value) {
    const raw = String(value || "").trim();
    if (raw) {
      try {
        const parsed = new URL(raw);
        if (parsed.protocol === "https:" && isSlackWorkspaceHostname(parsed.hostname)) {
          return parsed.origin;
        }
      } catch (_) {}
    }
    if (typeof window !== "undefined" && window.location && isSlackWorkspaceHostname(window.location.hostname)) {
      return window.location.origin;
    }
    return SLACK_DEFAULT_WORKSPACE_ORIGIN;
  }

  function generateSlackClientMessageId() {
    try {
      if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
        return crypto.randomUUID();
      }
    } catch (_) {}
    return "zip-slack-" + String(Date.now()) + "-" + String(Math.floor(Math.random() * 1000000));
  }

  function generateSlackLikeTs() {
    const now = Date.now();
    const seconds = Math.floor(now / 1000);
    const micros = String((now % 1000) * 1000 + Math.floor(Math.random() * 1000)).padStart(6, "0");
    return String(seconds) + "." + micros;
  }

  function extractUrlsFromText(value) {
    const text = String(value || "");
    if (!text) return [];
    const matches = text.match(/https?:\/\/[^\s)]+/gi);
    if (!matches || !matches.length) return [];
    const unique = [];
    for (let i = 0; i < matches.length; i += 1) {
      const url = String(matches[i] || "").trim();
      if (!url || unique.includes(url)) continue;
      unique.push(url);
      if (unique.length >= 8) break;
    }
    return unique;
  }

  function buildSingularityRichTextBlocks(singularityUserId, bodyText) {
    const text = String(bodyText || "");
    const elements = [];
    if (singularityUserId) {
      elements.push({ type: "user", user_id: singularityUserId });
      if (text) elements.push({ type: "text", text: " " + text });
    } else if (text) {
      elements.push({ type: "text", text });
    }
    if (!elements.length) return [];
    return [
      {
        type: "rich_text",
        elements: [
          {
            type: "rich_text_section",
            elements
          }
        ]
      }
    ];
  }

  function normalizeSlackMentionHandle(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    if (/^<@[UW][A-Z0-9]{8,}>$/i.test(raw)) return "";
    const plain = raw.startsWith("@") ? raw.slice(1) : raw;
    return String(plain || "").trim().toLowerCase();
  }

  function normalizeSlackHandleLoose(value) {
    const normalized = normalizeSlackMentionHandle(value);
    if (!normalized) return "";
    return normalized.replace(/[^a-z0-9._-]+/g, "");
  }

  function doesSlackUserMatchHandle(user, handle) {
    const target = normalizeSlackMentionHandle(handle);
    if (!target) return false;
    const targetLoose = normalizeSlackHandleLoose(target);
    const profile = user && user.profile && typeof user.profile === "object" ? user.profile : {};
    const candidates = [
      user && user.name,
      user && user.real_name,
      profile.display_name_normalized,
      profile.display_name,
      profile.real_name_normalized,
      profile.real_name
    ]
      .map((value) => String(value || "").trim())
      .filter(Boolean);
    for (let i = 0; i < candidates.length; i += 1) {
      const candidate = normalizeSlackMentionHandle(candidates[i]);
      if (!candidate) continue;
      if (candidate === target) return true;
      const candidateLoose = normalizeSlackHandleLoose(candidate);
      if (candidateLoose && targetLoose && candidateLoose === targetLoose) return true;
    }
    return false;
  }

  function doesSlackMessageIdentityMatchHandle(message, handle) {
    const target = normalizeSlackMentionHandle(handle);
    if (!target) return false;
    const targetLoose = normalizeSlackHandleLoose(target);
    const source = message && typeof message === "object" ? message : {};
    const profile = source.user_profile && typeof source.user_profile === "object" ? source.user_profile : {};
    const botProfile = source.bot_profile && typeof source.bot_profile === "object" ? source.bot_profile : {};
    const candidates = [
      source.username,
      source.app_name,
      source.user_display_name,
      profile.display_name_normalized,
      profile.display_name,
      profile.real_name_normalized,
      profile.real_name,
      botProfile.name,
      botProfile.app_name
    ]
      .map((value) => String(value || "").trim())
      .filter(Boolean);
    for (let i = 0; i < candidates.length; i += 1) {
      const candidate = normalizeSlackMentionHandle(candidates[i]);
      if (!candidate) continue;
      if (candidate === target) return true;
      const candidateLoose = normalizeSlackHandleLoose(candidate);
      if (candidateLoose && targetLoose && candidateLoose === targetLoose) return true;
    }
    return false;
  }

  async function resolveSlackUserIdByMention(workspaceOrigin, mention) {
    const handle = normalizeSlackMentionHandle(mention);
    if (!handle) return "";
    const origin = normalizeSlackWorkspaceOrigin(workspaceOrigin);
    const cacheKey = origin + "::" + handle;
    const cached = normalizeSlackUserId(slackMentionUserIdCache.get(cacheKey) || "");
    if (cached) return cached;

    let cursor = "";
    for (let page = 0; page < 3; page += 1) {
      const fields = {
        limit: 500,
        _x_reason: "zip-qai-resolve-mention-user"
      };
      if (cursor) fields.cursor = cursor;
      const usersList = await postSlackApi(origin, "/api/users.list", fields);
      if (!usersList || !usersList.ok) break;
      const payload = usersList.payload && typeof usersList.payload === "object" ? usersList.payload : {};
      const members = Array.isArray(payload.members) ? payload.members : [];
      for (let i = 0; i < members.length; i += 1) {
        const member = members[i];
        if (!member || typeof member !== "object") continue;
        const memberId = normalizeSlackUserId(member.id || member.user_id || "");
        if (!memberId) continue;
        if (!doesSlackUserMatchHandle(member, handle)) continue;
        slackMentionUserIdCache.set(cacheKey, memberId);
        return memberId;
      }
      cursor = String(payload && payload.response_metadata && payload.response_metadata.next_cursor || "").trim();
      if (!cursor) break;
    }
    return "";
  }

  async function resolveSlackUserIdFromChannelHistory(workspaceOrigin, channelId, mention) {
    const handle = normalizeSlackMentionHandle(mention);
    const targetChannel = String(channelId || "").trim();
    if (!handle || !targetChannel) return "";
    const origin = normalizeSlackWorkspaceOrigin(workspaceOrigin);
    const cacheKey = origin + "::" + handle;
    const cached = normalizeSlackUserId(slackMentionUserIdCache.get(cacheKey) || "");
    if (cached) return cached;

    const history = await postSlackApi(origin, "/api/conversations.history", {
      channel: targetChannel,
      limit: 120,
      inclusive: "false",
      _x_reason: "zip-qai-resolve-mention-history"
    }).catch(() => null);
    if (!history || !history.ok) return "";
    const payload = history.payload && typeof history.payload === "object" ? history.payload : {};
    const messages = Array.isArray(payload.messages) ? payload.messages : [];
    for (let i = 0; i < messages.length; i += 1) {
      const message = messages[i];
      if (!message || typeof message !== "object") continue;
      const messageUserId = normalizeSlackUserId(
        message.user
        || message.user_id
        || (message.user_profile && message.user_profile.id)
        || ""
      );
      if (!messageUserId) continue;
      if (!doesSlackMessageIdentityMatchHandle(message, handle)) continue;
      slackMentionUserIdCache.set(cacheKey, messageUserId);
      return messageUserId;
    }
    return "";
  }

  async function resolveSlackUserIdFromConversationMembers(workspaceOrigin, channelId, mention) {
    const handle = normalizeSlackMentionHandle(mention);
    const targetChannel = String(channelId || "").trim();
    if (!handle || !targetChannel) return "";
    const origin = normalizeSlackWorkspaceOrigin(workspaceOrigin);
    const cacheKey = origin + "::" + handle;
    const cached = normalizeSlackUserId(slackMentionUserIdCache.get(cacheKey) || "");
    if (cached) return cached;

    const membersResponse = await postSlackApi(origin, "/api/conversations.members", {
      channel: targetChannel,
      limit: 200,
      _x_reason: "zip-qai-resolve-mention-members"
    }).catch(() => null);
    if (!membersResponse || !membersResponse.ok) return "";
    const membersPayload = membersResponse.payload && typeof membersResponse.payload === "object"
      ? membersResponse.payload
      : {};
    const members = Array.isArray(membersPayload.members) ? membersPayload.members : [];
    for (let i = 0; i < members.length && i < 120; i += 1) {
      const memberId = normalizeSlackUserId(members[i]);
      if (!memberId) continue;
      const userInfo = await postSlackApi(origin, "/api/users.info", {
        user: memberId,
        include_locale: "false",
        _x_reason: "zip-qai-resolve-mention-member-info"
      }).catch(() => null);
      if (!userInfo || !userInfo.ok) continue;
      const userPayload = userInfo.payload && typeof userInfo.payload === "object" ? userInfo.payload : {};
      const user = userPayload.user && typeof userPayload.user === "object" ? userPayload.user : {};
      if (!doesSlackUserMatchHandle(user, handle)) continue;
      slackMentionUserIdCache.set(cacheKey, memberId);
      return memberId;
    }
    return "";
  }

  function decodeSlackEntityText(value) {
    return String(value == null ? "" : value)
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&#64;/gi, "@")
      .replace(/&quot;/gi, "\"")
      .replace(/&#39;/gi, "'");
  }

  function extractXoxcToken(value) {
    const text = String(value == null ? "" : value);
    const match = text.match(/(?:xoxe\.)?xox[a-z]-[A-Za-z0-9-]+/i);
    return match ? match[0] : "";
  }

  function normalizeSlackUserApiToken(value) {
    const token = extractXoxcToken(value);
    if (!token) return "";
    // Keep legacy behavior: accept any Slack xox* user/session token family.
    return token;
  }

  function isSlackWebSessionToken(value) {
    const token = normalizeSlackUserApiToken(value);
    if (!token) return false;
    return /^xoxc-/i.test(token)
      || /^xoxd-/i.test(token)
      || /^xoxe\.xoxc-/i.test(token)
      || /^xoxe\.xoxd-/i.test(token);
  }

  function cacheSlackCapturedToken(token) {
    const normalized = normalizeSlackUserApiToken(token);
    if (!normalized) return "";
    slackCapturedToken = normalized;
    return normalized;
  }

  function readCapturedSlackToken() {
    const cached = normalizeSlackUserApiToken(slackCapturedToken);
    if (cached) {
      slackCapturedToken = cached;
      return cached;
    }
    return "";
  }

  function installSlackTokenBridgeListener() {
    if (slackTokenBridgeListenerInstalled || typeof window === "undefined") return;
    slackTokenBridgeListenerInstalled = true;

    window.addEventListener("message", (event) => {
      try {
        if (!event || event.source !== window) return;
        const data = event.data;
        if (!data || typeof data !== "object" || data.type !== SLACK_BRIDGE_MESSAGE_TYPE) return;
        cacheSlackCapturedToken(data.token || data.value || "");
      } catch (_) {}
    });

    window.addEventListener(SLACK_BRIDGE_EVENT_NAME, (event) => {
      try {
        const detail = event && event.detail && typeof event.detail === "object" ? event.detail : null;
        if (!detail) return;
        cacheSlackCapturedToken(detail.token || detail.value || "");
      } catch (_) {}
    });
  }

  function ensureSlackTokenBridgeInstalled() {
    if (!isSlackPage()) return;
    installSlackTokenBridgeListener();
    if (slackTokenBridgeInstalled) return;

    try {
      const existingScript = document.getElementById(SLACK_TOKEN_BRIDGE_SCRIPT_ID);
      if (existingScript) {
        slackTokenBridgeInstalled = true;
        return;
      }

      const script = document.createElement("script");
      script.id = SLACK_TOKEN_BRIDGE_SCRIPT_ID;
      const bridgeScriptUrl = getRuntimeUrl(SLACK_TOKEN_BRIDGE_SCRIPT_PATH);
      if (!bridgeScriptUrl) return;
      script.src = bridgeScriptUrl;
      script.async = false;
      script.dataset.eventName = SLACK_BRIDGE_EVENT_NAME;
      script.dataset.messageType = SLACK_BRIDGE_MESSAGE_TYPE;
      script.onload = () => {
        slackTokenBridgeInstalled = true;
        script.dataset.loaded = "true";
      };
      script.onerror = () => {
        slackTokenBridgeInstalled = false;
        try { script.remove(); } catch (_) {}
      };

      const parent = document.documentElement || document.head || document.body;
      if (!parent) throw new Error("Missing document root");
      parent.appendChild(script);
      slackTokenBridgeInstalled = true;
    } catch (_) {
      slackTokenBridgeInstalled = false;
    }
  }

  function parseJsonMaybe(value) {
    if (value == null) return null;
    if (typeof value === "object") return value;
    const text = String(value || "").trim();
    if (!text) return null;
    if (text[0] !== "{" && text[0] !== "[") return null;
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  function findSlackTokenInValue(value, depth, seen) {
    if (depth > 4 || value == null) return "";
    if (typeof value === "string") {
      const direct = extractXoxcToken(value);
      if (direct) return direct;
      const parsed = parseJsonMaybe(value);
      if (parsed && typeof parsed === "object") {
        return findSlackTokenInValue(parsed, depth + 1, seen);
      }
      return "";
    }
    if (typeof value !== "object") return "";
    if (seen.has(value)) return "";
    seen.add(value);

    if (Array.isArray(value)) {
      const limit = Math.min(value.length, 60);
      for (let i = 0; i < limit; i += 1) {
        const token = findSlackTokenInValue(value[i], depth + 1, seen);
        if (token) return token;
      }
      return "";
    }

    const keyPriority = ["api_token", "token", "enterprise_token", "xoxc", "xoxc_token", "user_token"];
    for (let i = 0; i < keyPriority.length; i += 1) {
      const key = keyPriority[i];
      if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
      const token = findSlackTokenInValue(value[key], depth + 1, seen);
      if (token) return token;
    }

    const keys = Object.keys(value);
    const limit = Math.min(keys.length, 80);
    for (let i = 0; i < limit; i += 1) {
      const key = keys[i];
      const token = findSlackTokenInValue(value[key], depth + 1, seen);
      if (token) return token;
    }
    return "";
  }

  function findSlackTokenInGlobals() {
    if (typeof window === "undefined") return "";
    const globals = [];
    try { globals.push(window.boot_data); } catch (_) {}
    try { globals.push(window.__BOOT_DATA__); } catch (_) {}
    try { globals.push(window.TS); } catch (_) {}
    try { globals.push(window.TS && window.TS.boot_data); } catch (_) {}
    try { globals.push(window.TS && window.TS.model); } catch (_) {}
    try { globals.push(window.__INITIAL_STATE__); } catch (_) {}
    try { globals.push(window.__STATE__); } catch (_) {}

    for (let i = 0; i < globals.length; i += 1) {
      const token = findSlackTokenInValue(globals[i], 0, new WeakSet());
      if (token) return token;
    }
    return "";
  }

  function scoreStorageKey(key) {
    const value = String(key || "").toLowerCase();
    if (!value) return 0;
    if (value.includes("api_token")) return 10;
    if (value.includes("token")) return 8;
    if (value.includes("localconfig")) return 7;
    if (value.includes("boot")) return 5;
    if (value.includes("auth")) return 4;
    return 1;
  }

  function findSlackTokenInStorage(storage) {
    if (!storage || typeof storage.length !== "number") return "";
    const keys = [];
    const count = Math.min(storage.length, 250);
    for (let i = 0; i < count; i += 1) {
      try {
        const key = storage.key(i);
        if (key) keys.push(String(key));
      } catch (_) {}
    }
    keys.sort((a, b) => scoreStorageKey(b) - scoreStorageKey(a));
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      let raw = "";
      try {
        raw = String(storage.getItem(key) || "");
      } catch (_) {
        continue;
      }
      const token = findSlackTokenInValue(raw, 0, new WeakSet());
      if (token) return token;
    }
    return "";
  }

  function resolveSlackApiTokenCandidates(preferredToken, options) {
    const opts = options && typeof options === "object" ? options : {};
    const preferProvidedTokenFirst = opts.preferProvidedTokenFirst === true;
    ensureSlackTokenBridgeInstalled();
    const candidates = [];
    const pushToken = (value, cache) => {
      const normalized = normalizeSlackUserApiToken(value);
      if (!normalized) return;
      if (!candidates.includes(normalized)) candidates.push(normalized);
      if (cache) cacheSlackCapturedToken(normalized);
    };

    if (preferProvidedTokenFirst) {
      pushToken(preferredToken, false);
    }
    pushToken(readCapturedSlackToken(), false);

    const fromGlobals = findSlackTokenInGlobals();
    pushToken(fromGlobals, true);
    try {
      const fromLocalStorage = findSlackTokenInStorage(window.localStorage);
      pushToken(fromLocalStorage, true);
    } catch (_) {}
    try {
      const fromSessionStorage = findSlackTokenInStorage(window.sessionStorage);
      pushToken(fromSessionStorage, true);
    } catch (_) {}
    // Keep caller-provided token as lowest-priority fallback unless explicitly promoted.
    if (!preferProvidedTokenFirst) pushToken(preferredToken, false);
    return candidates;
  }

  function resolveSlackApiToken(preferredToken, options) {
    const candidates = resolveSlackApiTokenCandidates(preferredToken, options);
    return candidates.length ? candidates[0] : "";
  }

  function getSlackApiFailureCode(payload, fallback) {
    const code = payload && typeof payload === "object"
      ? String(payload.error || payload.code || "").trim().toLowerCase()
      : "";
    if (code) return code;
    return String(fallback || "").trim().toLowerCase();
  }

  function isRetryableSlackTokenFailureCode(value) {
    const code = String(value || "").trim().toLowerCase();
    if (!code) return false;
    return code === "invalid_auth"
      || code === "not_authed"
      || code === "token_revoked"
      || code === "account_inactive"
      || code === "missing_scope"
      || code === "insufficient_scope"
      || code === "not_allowed_token_type"
      || code === "channel_not_found"
      || code === "not_in_channel"
      || code === "workspace_mismatch"
      || code === "user_mismatch";
  }

  function clearSlackCapturedTokenIfMatches(token) {
    const normalized = normalizeSlackUserApiToken(token);
    if (!normalized) return;
    const cached = readCapturedSlackToken();
    if (cached && cached === normalized) {
      slackCapturedToken = "";
    }
    slackTokenTeamIdByToken.delete(normalized);
    slackTokenUserIdByToken.delete(normalized);
  }

  async function resolveSlackTokenTeamId(candidateOrigins, token) {
    const identity = await resolveSlackTokenIdentity(candidateOrigins, token);
    if (identity && identity.ok) {
      return { ok: true, teamId: identity.teamId || "" };
    }
    return {
      ok: false,
      code: String(identity && identity.code || "slack_auth_failed").trim().toLowerCase(),
      error: String(identity && identity.error || "Slack token team check failed.").trim()
    };
  }

  async function resolveSlackTokenIdentity(candidateOrigins, token) {
    const normalizedToken = normalizeSlackUserApiToken(token);
    if (!normalizedToken) {
      return { ok: false, code: "invalid_auth", error: "Slack token is missing." };
    }
    const cachedTeamId = normalizeSlackTeamId(slackTokenTeamIdByToken.get(normalizedToken) || "");
    const cachedUserId = normalizeSlackUserId(slackTokenUserIdByToken.get(normalizedToken) || "");
    if (cachedTeamId || cachedUserId) {
      return { ok: true, teamId: cachedTeamId, userId: cachedUserId };
    }
    const origins = Array.isArray(candidateOrigins) ? candidateOrigins : [];
    let lastFailure = null;
    for (let i = 0; i < origins.length; i += 1) {
      const origin = normalizeSlackWorkspaceOrigin(origins[i]);
      if (!origin) continue;
      const attempt = await postSlackApiAttempt(origin, "/api/auth.test", {
        _x_reason: "zip-token-team-check"
      }, normalizedToken).catch((err) => ({
        ok: false,
        code: "slack_api_network_error",
        error: err && err.message ? err.message : "Slack token team check failed."
      }));
      if (attempt && attempt.ok) {
        const payload = attempt.payload && typeof attempt.payload === "object" ? attempt.payload : {};
        const teamId = normalizeSlackTeamId(payload.team_id || payload.team || "");
        const userId = normalizeSlackUserId(payload.user_id || payload.user || "");
        if (teamId) slackTokenTeamIdByToken.set(normalizedToken, teamId);
        if (userId) slackTokenUserIdByToken.set(normalizedToken, userId);
        return { ok: true, teamId, userId };
      }
      if (attempt && typeof attempt === "object") {
        lastFailure = {
          code: String(attempt.code || "").trim().toLowerCase(),
          error: String(attempt.error || "Slack token team check failed.").trim()
        };
      }
    }
    return {
      ok: false,
      code: String(lastFailure && lastFailure.code || "slack_auth_failed").trim().toLowerCase(),
      error: String(lastFailure && lastFailure.error || "Slack token team check failed.").trim()
    };
  }

  async function postSlackApiAttempt(candidateOrigin, path, body, token) {
    const buildFormData = () => {
      const formData = new FormData();
      appendSlackFormField(formData, "token", token);
      const keys = Object.keys(body);
      for (let i = 0; i < keys.length; i += 1) {
        appendSlackFormField(formData, keys[i], body[keys[i]]);
      }
      if (!Object.prototype.hasOwnProperty.call(body, "_x_mode")) {
        appendSlackFormField(formData, "_x_mode", "online");
      }
      if (!Object.prototype.hasOwnProperty.call(body, "_x_sonic")) {
        appendSlackFormField(formData, "_x_sonic", "true");
      }
      if (!Object.prototype.hasOwnProperty.call(body, "_x_app_name")) {
        appendSlackFormField(formData, "_x_app_name", "client");
      }
      return formData;
    };
    const url = new URL(path, candidateOrigin).toString();
    const response = await fetch(url, {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      headers: { Accept: "application/json" },
      body: buildFormData()
    });
    const parsed = await parseSlackApiResponse(response);
    const payload = parsed.payload && typeof parsed.payload === "object" ? parsed.payload : null;
    const payloadOk = payload ? payload.ok !== false : false;
    if (response.ok && payloadOk) {
      return {
        ok: true,
        status: response.status,
        payload,
        rawText: parsed.text,
        code: ""
      };
    }
    return {
      ok: false,
      status: response.status,
      error: getSlackApiError(payload, parsed.text, "Slack API request failed."),
      payload: payload || {},
      rawText: parsed.text,
      code: getSlackApiFailureCode(payload, "")
    };
  }

  function appendSlackFormField(formData, key, value) {
    if (!formData || !key) return;
    if (value == null) return;
    if (typeof value === "string") {
      formData.append(key, value);
      return;
    }
    if (typeof value === "number" || typeof value === "boolean") {
      formData.append(key, String(value));
      return;
    }
    try {
      formData.append(key, JSON.stringify(value));
    } catch (_) {
      formData.append(key, String(value));
    }
  }

  async function parseSlackApiResponse(response) {
    const text = await response.text();
    let payload = null;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch (_) {}
    return { text, payload };
  }

  function getSlackApiError(payload, text, fallback) {
    const message = payload && typeof payload === "object"
      ? (payload.error || payload.message || payload.detail || payload.warning || "")
      : "";
    const normalized = String(message || text || fallback || "Slack API request failed").trim();
    return normalized || "Slack API request failed";
  }

  async function postSlackApi(workspaceOrigin, endpointPath, fields) {
    const origin = normalizeSlackWorkspaceOrigin(workspaceOrigin);
    if (!origin) {
      return { ok: false, error: "Invalid Slack workspace origin." };
    }
    let parsedOrigin = null;
    try {
      parsedOrigin = new URL(origin);
    } catch (_) {
      return { ok: false, error: "Invalid Slack workspace origin." };
    }
    if (!isSlackWorkspaceHostname(parsedOrigin.hostname)) {
      return { ok: false, error: "Invalid Slack workspace origin." };
    }

    const path = String(endpointPath || "").startsWith("/") ? String(endpointPath) : ("/" + String(endpointPath || ""));
    const body = fields && typeof fields === "object" ? fields : {};
    const candidateOrigins = [];
    const pushOrigin = (value) => {
      const normalized = normalizeSlackWorkspaceOrigin(value);
      if (!normalized) return;
      if (!candidateOrigins.includes(normalized)) candidateOrigins.push(normalized);
    };
    pushOrigin(origin);
    if (typeof window !== "undefined" && window.location && window.location.origin) {
      pushOrigin(window.location.origin);
    }

    let lastFailure = null;
    for (let authRetry = 0; authRetry <= 2; authRetry += 1) {
      const tokenCandidates = resolveSlackApiTokenCandidates();
      const orderedTokens = tokenCandidates
        .slice()
        .sort((a, b) => {
          const aPriority = isSlackWebSessionToken(a) ? 0 : 1;
          const bPriority = isSlackWebSessionToken(b) ? 0 : 1;
          return aPriority - bPriority;
        });
      if (!orderedTokens.length) {
        lastFailure = { ok: false, code: "invalid_auth", error: "No Slack web session token found. Open Slack and complete login first." };
      } else {
        lastFailure = null;
      }

      for (let tokenIdx = 0; tokenIdx < orderedTokens.length; tokenIdx += 1) {
        const token = normalizeSlackUserApiToken(orderedTokens[tokenIdx]);
        if (!token) continue;
        cacheSlackCapturedToken(token);
        let tokenFailure = null;

        for (let originIdx = 0; originIdx < candidateOrigins.length; originIdx += 1) {
          const candidateOrigin = candidateOrigins[originIdx];
          try {
            const attempt = await postSlackApiAttempt(candidateOrigin, path, body, token);
            if (attempt && attempt.ok) {
              return {
                ok: true,
                status: attempt.status,
                payload: attempt.payload || {},
                rawText: String(attempt.rawText || "")
              };
            }
            tokenFailure = {
              ok: false,
              status: Number(attempt && attempt.status || 0),
              error: String((attempt && attempt.error) || "Slack API request failed."),
              payload: attempt && attempt.payload && typeof attempt.payload === "object" ? attempt.payload : {},
              rawText: String((attempt && attempt.rawText) || ""),
              code: getSlackApiFailureCode(
                attempt && attempt.payload && typeof attempt.payload === "object" ? attempt.payload : null,
                String((attempt && attempt.code) || "")
              )
            };
          } catch (err) {
            tokenFailure = {
              ok: false,
              error: err && err.message ? err.message : "Slack API request failed.",
              code: ""
            };
          }
        }

        if (tokenFailure) {
          const failureCode = getSlackApiFailureCode(tokenFailure.payload, tokenFailure.code || tokenFailure.error);
          if (
            failureCode === "invalid_auth"
            || failureCode === "not_authed"
            || failureCode === "token_revoked"
            || failureCode === "account_inactive"
          ) {
            clearSlackCapturedTokenIfMatches(token);
          }
          lastFailure = tokenFailure;
          if (!isRetryableSlackTokenFailureCode(failureCode)) {
            break;
          }
        }
      }

      const overallCode = getSlackApiFailureCode(
        lastFailure && lastFailure.payload && typeof lastFailure.payload === "object" ? lastFailure.payload : null,
        String(lastFailure && (lastFailure.code || lastFailure.error) || "")
      );
      const shouldRetryAuth = authRetry < 2 && (
        overallCode === "invalid_auth"
        || overallCode === "not_authed"
        || overallCode === "token_revoked"
        || overallCode === "account_inactive"
      );
      if (!shouldRetryAuth) {
        break;
      }
      await waitMs(600 + (authRetry * 400));
    }

    return lastFailure || { ok: false, error: "Slack API request failed." };
  }

  function slackTsToEpochMs(ts) {
    const value = Number(ts);
    if (!Number.isFinite(value) || value <= 0) return 0;
    return Math.trunc(value * 1000);
  }

  function extractRichTextElementsPlain(elements, parts) {
    const rows = Array.isArray(elements) ? elements : [];
    const out = Array.isArray(parts) ? parts : [];
    for (let i = 0; i < rows.length; i += 1) {
      const node = rows[i];
      if (!node || typeof node !== "object") continue;
      const type = String(node.type || "").trim().toLowerCase();
      if (type === "text") {
        out.push(String(node.text || ""));
        continue;
      }
      if (type === "link") {
        out.push(String(node.url || node.text || ""));
        continue;
      }
      if (type === "user") {
        const userId = String(node.user_id || "").trim();
        if (userId) out.push("<@" + userId + ">");
        continue;
      }
      if (Array.isArray(node.elements)) {
        extractRichTextElementsPlain(node.elements, out);
      }
      if (Array.isArray(node.items)) {
        extractRichTextElementsPlain(node.items, out);
      }
    }
    return out;
  }

  function extractSlackBlocksText(blocks) {
    const rows = Array.isArray(blocks) ? blocks : [];
    const parts = [];
    for (let i = 0; i < rows.length; i += 1) {
      const block = rows[i];
      if (!block || typeof block !== "object") continue;
      if (Array.isArray(block.elements)) {
        extractRichTextElementsPlain(block.elements, parts);
      }
      if (block.text && typeof block.text === "object") {
        const plain = String(block.text.text || "").trim();
        if (plain) parts.push(plain);
      }
    }
    return parts.join("").trim();
  }

  function extractSlackMessageText(message) {
    if (!message || typeof message !== "object") return "";
    const parts = [];
    const directText = String(message.text || "").trim();
    if (directText) parts.push(directText);

    const blockText = extractSlackBlocksText(message.blocks);
    if (blockText && !parts.includes(blockText)) parts.push(blockText);

    const attachments = Array.isArray(message.attachments) ? message.attachments : [];
    for (let i = 0; i < attachments.length; i += 1) {
      const attachment = attachments[i];
      if (!attachment || typeof attachment !== "object") continue;
      const lines = [attachment.pretext, attachment.title, attachment.text, attachment.fallback, attachment.from_url]
        .map((item) => String(item || "").trim())
        .filter(Boolean);
      if (lines.length) parts.push(lines.join("\n"));
    }

    const files = Array.isArray(message.files) ? message.files : [];
    for (let i = 0; i < files.length; i += 1) {
      const file = files[i];
      if (!file || typeof file !== "object") continue;
      const name = String(file.name || file.title || "attachment").trim();
      const url = String(file.url_private || file.url_private_download || file.permalink || "").trim();
      parts.push(url ? (name + ": " + url) : name);
    }

    return parts.join("\n\n").trim();
  }

  function isSingularityMessage(message, options) {
    if (!message || typeof message !== "object") return false;
    const opts = options && typeof options === "object" ? options : {};
    const singularityUserId = String(opts.singularityUserId || "").trim();
    const messageUserId = String(message.user || "").trim();
    if (singularityUserId && messageUserId && messageUserId === singularityUserId) return true;

    const singularityNamePattern = String(opts.singularityNamePattern || "").trim().toLowerCase();
    const botProfile = message.bot_profile && typeof message.bot_profile === "object" ? message.bot_profile : null;
    const profile = message.user_profile && typeof message.user_profile === "object" ? message.user_profile : null;
    const identityBlob = [
      message.username,
      botProfile && botProfile.name,
      botProfile && botProfile.app_name,
      profile && profile.display_name,
      profile && profile.real_name
    ].map((value) => String(value || "").trim().toLowerCase()).join(" ");
    if (!identityBlob) return false;
    if (!singularityNamePattern) return false;
    return identityBlob.includes(singularityNamePattern);
  }

  function hasSlackFinalMarker(message, markerRegexText) {
    const markerSource = String(markerRegexText || SLACK_DEFAULT_FINAL_MARKER_REGEX).trim();
    const text = extractSlackMessageText(message);
    if (markerSource && text) {
      try {
        const regex = new RegExp(markerSource, "i");
        if (regex.test(text)) return true;
      } catch (_) {
        if (text.toLowerCase().includes(markerSource.toLowerCase())) return true;
      }
    }

    const metadata = message && message.metadata && typeof message.metadata === "object" ? message.metadata : null;
    const eventPayload = metadata && metadata.event_payload && typeof metadata.event_payload === "object"
      ? metadata.event_payload
      : null;
    if (eventPayload) {
      if (eventPayload.FINAL_RESPONSE === true || eventPayload.final_response === true || eventPayload.final === true) {
        return true;
      }
    }
    return false;
  }

  function hasSingularityCompletionFooterText(value) {
    const text = String(value || "").replace(/\r\n?/g, "\n").trim().toLowerCase();
    if (!text) return false;
    if (text.includes("how helpful was this answer")) return true;
    if (text.includes("ai generated content. check important info for mistakes")) return true;
    if (text.includes("if you have any more questions, just tag me in this thread")) return true;
    if (text.includes("sources:")) return true;
    return false;
  }

  function hasSlackSourcesFooterText(value) {
    const text = String(value || "").replace(/\r\n?/g, "\n").trim().toLowerCase();
    if (!text) return false;
    const idx = text.lastIndexOf("\nsources:");
    const start = idx >= 0 ? idx + 1 : (text.startsWith("sources:") ? 0 : -1);
    if (start < 0) return false;
    const tail = text.slice(start);
    if (!tail.includes("sources:")) return false;
    if (!tail.includes("confidence-source")) return false;
    return true;
  }

  function normalizeSlackTextForDedup(value) {
    return String(value || "")
      .replace(/\r\n?/g, "\n")
      .replace(/[ \t]+/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .toLowerCase();
  }

  function toPriorSlackTs(value) {
    const raw = String(value || "").trim();
    const match = raw.match(/^(\d+)\.(\d+)$/);
    if (!match) {
      const asInt = Number.parseInt(raw, 10);
      if (Number.isFinite(asInt) && asInt > 0) return String(asInt - 1) + ".999999";
      return "0.000000";
    }
    let seconds = Number.parseInt(match[1], 10);
    let micros = Number.parseInt(match[2].slice(0, 6).padEnd(6, "0"), 10);
    if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
    if (!Number.isFinite(micros) || micros < 0) micros = 0;
    if (micros > 0) {
      micros -= 1;
    } else if (seconds > 0) {
      seconds -= 1;
      micros = 999999;
    }
    return String(seconds) + "." + String(micros).padStart(6, "0");
  }

  function parseSlackTsParts(value) {
    const raw = String(value || "").trim();
    if (!raw) return null;
    const match = raw.match(/^(\d+)(?:\.(\d+))?$/);
    if (!match) return null;
    const seconds = Number.parseInt(match[1], 10);
    const micros = Number.parseInt(String(match[2] || "0").slice(0, 6).padEnd(6, "0"), 10);
    if (!Number.isFinite(seconds) || seconds < 0) return null;
    if (!Number.isFinite(micros) || micros < 0) return null;
    return { seconds, micros };
  }

  function compareSlackTs(leftValue, rightValue) {
    const left = parseSlackTsParts(leftValue);
    const right = parseSlackTsParts(rightValue);
    if (!left || !right) return 0;
    if (left.seconds < right.seconds) return -1;
    if (left.seconds > right.seconds) return 1;
    if (left.micros < right.micros) return -1;
    if (left.micros > right.micros) return 1;
    return 0;
  }

  function slackTsToMicros(value) {
    const parts = parseSlackTsParts(value);
    if (!parts) return null;
    return (parts.seconds * 1000000) + parts.micros;
  }

  function normalizeSlackReadCursorTs(readCursorTs, messageTs) {
    const targetTs = String(messageTs || "").trim();
    const fallbackTs = toPriorSlackTs(targetTs);
    const candidateTs = String(readCursorTs || "").trim();
    if (!candidateTs) return fallbackTs;
    if (compareSlackTs(candidateTs, targetTs) >= 0) return fallbackTs;
    return candidateTs;
  }

  async function getSlackLatestMessageTs(workspaceOrigin, channelId, reasonPrefix) {
    const targetChannel = String(channelId || "").trim();
    if (!targetChannel) return "";
    const result = await postSlackApi(workspaceOrigin, "/api/conversations.history", {
      channel: targetChannel,
      limit: 1,
      inclusive: "false",
      _x_reason: String(reasonPrefix || "zip-slack-history").trim() + "-latest"
    }).catch(() => null);
    if (!result || !result.ok) return "";
    const payload = result.payload && typeof result.payload === "object" ? result.payload : {};
    const messages = Array.isArray(payload.messages) ? payload.messages : [];
    if (!messages.length) return "";
    return String(messages[0] && messages[0].ts || "").trim();
  }

  async function isSlackMessageUnreadInChannel(workspaceOrigin, channelId, messageTs, readCursorTs, reasonPrefix) {
    const targetChannel = String(channelId || "").trim();
    const targetTs = String(messageTs || "").trim();
    if (!targetChannel || !targetTs) return false;
    const cursorTs = normalizeSlackReadCursorTs(readCursorTs, targetTs);
    const result = await postSlackApi(workspaceOrigin, "/api/conversations.info", {
      channel: targetChannel,
      include_num_members: "false",
      _x_reason: String(reasonPrefix || "zip-slack-mark-unread").trim() + "-verify"
    }).catch(() => null);
    if (!result || !result.ok) return false;
    const payload = result.payload && typeof result.payload === "object" ? result.payload : {};
    const channel = payload.channel && typeof payload.channel === "object" ? payload.channel : {};
    const lastRead = String(channel.last_read || "").trim();
    if (!lastRead) return false;
    if (compareSlackTs(lastRead, targetTs) >= 0) return false;
    if (compareSlackTs(lastRead, cursorTs) < 0) return false;
    const targetMicros = slackTsToMicros(targetTs);
    const lastReadMicros = slackTsToMicros(lastRead);
    if (targetMicros == null || lastReadMicros == null) return false;
    const deltaSeconds = (targetMicros - lastReadMicros) / 1000000;
    return deltaSeconds >= 0 && deltaSeconds <= 2.5;
  }

  function isSingularityAckMessageText(value) {
    const text = normalizeSlackTextForDedup(value);
    if (!text) return false;
    if (text.length > 420) return false;
    const ackHints = [
      "processing your request",
      "working on your request",
      "just a moment",
      "please wait",
      "i'm thinking",
      "im thinking",
      "thinking..."
    ];
    for (let i = 0; i < ackHints.length; i += 1) {
      if (text.includes(ackHints[i])) return true;
    }
    return false;
  }

  async function slackConversationsMark(workspaceOrigin, channelId, ts, reason) {
    if (!channelId || !ts) return { ok: false };
    return postSlackApi(workspaceOrigin, "/api/conversations.mark", {
      channel: channelId,
      ts,
      _x_reason: reason || "viewed"
    });
  }

  async function slackThreadMark(workspaceOrigin, channelId, threadTs, ts, read) {
    if (!channelId || !threadTs || !ts) return { ok: false };
    return postSlackApi(workspaceOrigin, "/api/subscriptions.thread.mark", {
      channel: channelId,
      thread_ts: threadTs,
      ts,
      read: read ? "true" : "false",
      _x_reason: "marking-thread"
    });
  }

  async function markSlackMessageUnread(workspaceOrigin, channelId, messageTs, reasonPrefix, readCursorTs) {
    const targetChannel = String(channelId || "").trim();
    const targetTs = String(messageTs || "").trim();
    if (!targetChannel || !targetTs) return false;

    const reasonBase = String(reasonPrefix || "zip-slack-mark-unread").trim() || "zip-slack-mark-unread";
    const cursorTs = normalizeSlackReadCursorTs(readCursorTs, targetTs);
    const delays = [0, 180];
    for (let pass = 0; pass < delays.length; pass += 1) {
      if (delays[pass] > 0) await waitMs(delays[pass]);
      const markResult = await slackConversationsMark(
        workspaceOrigin,
        targetChannel,
        cursorTs,
        reasonBase + "-mark-cursor"
      ).catch(() => null);
      if (markResult && markResult.ok) {
        const verified = await isSlackMessageUnreadInChannel(
          workspaceOrigin,
          targetChannel,
          targetTs,
          cursorTs,
          reasonBase
        );
        if (verified) return true;
      }
    }
    return false;
  }

  function normalizeSlackTeamId(value) {
    const id = String(value || "").trim();
    if (!id) return "";
    return /^[TE][A-Z0-9]{8,}$/i.test(id) ? id : "";
  }

  function normalizeSlackUserId(value) {
    const id = String(value || "").trim();
    if (!id) return "";
    return /^[UW][A-Z0-9]{8,}$/i.test(id) ? id : "";
  }

  function normalizeSlackAvatarUrl(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(raw, String(window.location && window.location.origin || ""));
      const host = String(parsed.hostname || "").toLowerCase();
      if (
        host === "slack-edge.com"
        || host.endsWith(".slack-edge.com")
        || host === "slack.com"
        || host.endsWith(".slack.com")
      ) {
        return parsed.toString();
      }
    } catch (_) {}
    return "";
  }

  function isSlackStatusAssetUrl(value) {
    const raw = String(value || "").trim();
    if (!raw) return false;
    try {
      const parsed = new URL(raw, String(window.location && window.location.origin || ""));
      if (String(parsed.protocol || "").toLowerCase() !== "https:") return false;
      const host = String(parsed.hostname || "").toLowerCase();
      const pathname = String(parsed.pathname || "").toLowerCase();
      if (host === "emoji.slack-edge.com" || host.endsWith(".emoji.slack-edge.com")) {
        return true;
      }
      if (
        host !== "slack-edge.com"
        && !host.endsWith(".slack-edge.com")
        && host !== "slack.com"
        && !host.endsWith(".slack.com")
      ) {
        return false;
      }
      return (
        pathname.includes("/emoji")
        || pathname.includes("emoji-assets")
        || pathname.includes("custom_emoji")
        || pathname.includes("status_emoji")
      );
    } catch (_) {}
    return false;
  }

  function sanitizeSlackAvatarCandidate(value, statusIconUrl) {
    const avatarUrl = normalizeSlackAvatarUrl(value);
    if (!avatarUrl) return "";
    const normalizedStatusIconUrl = normalizeSlackStatusIconUrl(statusIconUrl);
    if (normalizedStatusIconUrl && avatarUrl === normalizedStatusIconUrl) return "";
    if (isSlackStatusAssetUrl(avatarUrl)) return "";
    return avatarUrl;
  }

  function normalizeSlackStatusIconName(value) {
    const name = String(value || "").trim().toLowerCase();
    if (!name) return "";
    return /^[a-z0-9_+\-]{1,64}$/.test(name) ? (":" + name + ":") : "";
  }

  function normalizeSlackStatusIcon(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const alias = normalizeSlackStatusIconName(raw);
    if (alias) return alias;
    if (/^:[a-z0-9_+\-]{1,64}:$/i.test(raw)) return raw.toLowerCase();
    const normalized = raw.replace(/\s+/g, " ").trim();
    if (!normalized) return "";
    return normalized.slice(0, 32);
  }

  function normalizeSlackStatusIconUrl(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(raw, String(window.location && window.location.origin || ""));
      if (String(parsed.protocol || "").toLowerCase() !== "https:") return "";
      return parsed.toString();
    } catch (_) {}
    return "";
  }

  function normalizeSlackStatusMessage(value) {
    const normalized = String(value || "").replace(/\s+/g, " ").trim();
    if (!normalized) return "";
    return normalized.slice(0, 160);
  }

  function normalizeSlackDisplayName(value) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    if (!text || text.length > 80) return "";
    if (/^:[a-z0-9_+\-]{1,64}:$/i.test(text)) return "";
    if (normalizeSlackUserId(text)) return "";
    const lower = text.toLowerCase();
    if (
      lower === "you"
      || lower === "profile"
      || lower === "account"
      || lower === "user menu"
      || lower === "menu"
      || lower === "zip"
      || lower === "ziptool"
    ) {
      return "";
    }
    return text;
  }

  function pickSlackSessionUserName(candidate) {
    if (!candidate || typeof candidate !== "object") return "";
    const directUserId = normalizeSlackUserId(
      candidate.user_id
      || candidate.userId
      || (candidate.user && candidate.user.id)
      || (candidate.user && candidate.user.user_id)
      || candidate.id
    );
    const allowDirectFields = !!directUserId;
    const user = candidate.user && typeof candidate.user === "object" ? candidate.user : null;
    const profile = user && user.profile && typeof user.profile === "object" ? user.profile : null;
    const directProfile = candidate.profile && typeof candidate.profile === "object" ? candidate.profile : null;
    const values = [
      allowDirectFields ? candidate.user_name : "",
      allowDirectFields ? candidate.username : "",
      allowDirectFields ? candidate.real_name : "",
      allowDirectFields ? candidate.display_name : "",
      user && user.real_name,
      user && user.name,
      user && user.display_name,
      profile && profile.display_name_normalized,
      profile && profile.display_name,
      profile && profile.real_name_normalized,
      profile && profile.real_name,
      directProfile && directProfile.display_name_normalized,
      directProfile && directProfile.display_name,
      directProfile && directProfile.real_name_normalized,
      directProfile && directProfile.real_name
    ];
    for (let i = 0; i < values.length; i += 1) {
      const name = normalizeSlackDisplayName(values[i]);
      if (name) return name;
    }
    return "";
  }

  function pickSlackSessionAvatarUrl(candidate) {
    if (!candidate || typeof candidate !== "object") return "";
    const directUserId = normalizeSlackUserId(
      candidate.user_id
      || candidate.userId
      || (candidate.user && candidate.user.id)
      || (candidate.user && candidate.user.user_id)
      || candidate.id
    );
    const allowDirectFields = !!directUserId;
    const user = candidate.user && typeof candidate.user === "object" ? candidate.user : null;
    const profile = user && user.profile && typeof user.profile === "object" ? user.profile : null;
    const directProfile = candidate.profile && typeof candidate.profile === "object" ? candidate.profile : null;
    const statusIconUrl = pickSlackSessionStatusIconUrl(candidate);
    const values = [
      allowDirectFields ? candidate.avatar_url : "",
      allowDirectFields ? candidate.image_192 : "",
      allowDirectFields ? candidate.image_72 : "",
      user && user.image_192,
      user && user.image_72,
      profile && profile.image_192,
      profile && profile.image_72,
      profile && profile.image_48,
      directProfile && directProfile.image_192,
      directProfile && directProfile.image_72,
      directProfile && directProfile.image_48
    ];
    for (let i = 0; i < values.length; i += 1) {
      const url = sanitizeSlackAvatarCandidate(values[i], statusIconUrl);
      if (url) return url;
    }
    return "";
  }

  function pickSlackSessionStatusIconUrl(candidate) {
    if (!candidate || typeof candidate !== "object") return "";
    const user = candidate.user && typeof candidate.user === "object" ? candidate.user : null;
    const profile = user && user.profile && typeof user.profile === "object" ? user.profile : null;
    const directProfile = candidate.profile && typeof candidate.profile === "object" ? candidate.profile : null;
    const profileDisplayInfo = pickSlackStatusFromDisplayInfo(profile && profile.status_emoji_display_info || null);
    const directProfileDisplayInfo = pickSlackStatusFromDisplayInfo(
      directProfile && directProfile.status_emoji_display_info || null
    );
    const values = [
      candidate.status_icon_url,
      candidate.statusIconUrl,
      profile && profile.status_emoji_url,
      profileDisplayInfo.statusIconUrl,
      directProfile && directProfile.status_emoji_url,
      directProfileDisplayInfo.statusIconUrl
    ];
    for (let i = 0; i < values.length; i += 1) {
      const url = normalizeSlackStatusIconUrl(values[i]);
      if (url) return url;
    }
    return "";
  }

  function normalizeSlackDomIdentityName(value) {
    let text = String(value || "").replace(/\s+/g, " ").trim();
    if (!text) return "";
    const lower = text.toLowerCase();
    if (
      lower === "you"
      || lower === "profile"
      || lower === "account"
      || lower === "user menu"
      || lower === "menu"
      || lower === "zip"
      || lower === "ziptool"
    ) {
      return "";
    }
    text = text.replace(/^profile(?:\s+menu)?(?:\s+for)?\s+/i, "");
    text = text.replace(/^account(?:\s+menu)?(?:\s+for)?\s+/i, "");
    text = text.replace(/^signed in as\s+/i, "");
    text = text.replace(/\s+\b(menu|profile|account|settings)\b$/i, "");
    text = text.trim();
    return normalizeSlackDisplayName(text);
  }

  function extractSlackIdentityFromDom() {
    if (typeof document === "undefined" || !document.querySelectorAll) return { userName: "", avatarUrl: "" };
    const selectors = [
      'button[data-qa="user-button"] img',
      '[data-qa="user-button"] img',
      'button[data-qa*="user"] img',
      '[id*="team_menu_user_menu"] img',
      'button[aria-label*="profile" i] img',
      'button[aria-label*="account" i] img',
      'button[aria-label*="you" i] img'
    ];
    for (let i = 0; i < selectors.length; i += 1) {
      const nodes = document.querySelectorAll(selectors[i]);
      for (let j = 0; j < nodes.length; j += 1) {
        const img = nodes[j];
        if (!img) continue;
        const avatarUrl = sanitizeSlackAvatarCandidate(
          img.currentSrc
          || img.src
          || img.getAttribute("src")
          || img.getAttribute("data-src")
          || "",
          ""
        );
        if (!avatarUrl) continue;
        const owner = img.closest("button, [role='button'], a, [aria-label], [title]");
        const userName = normalizeSlackDomIdentityName(
          (img.getAttribute("alt") || "")
          || (owner && (owner.getAttribute("aria-label") || owner.getAttribute("title"))) || ""
        );
        return {
          userName,
          avatarUrl
        };
      }
    }
    return { userName: "", avatarUrl: "" };
  }

  function extractSlackSessionIdentity() {
    let teamId = "";
    let userId = "";
    let userName = "";
    let avatarUrl = "";
    const assign = (candidate) => {
      if (!candidate || typeof candidate !== "object") return;
      if (!teamId) {
        teamId = normalizeSlackTeamId(
          candidate.team_id
          || candidate.teamId
          || (candidate.team && candidate.team.id)
          || (candidate.team && candidate.team.team_id)
          || candidate.enterprise_id
        );
      }
      if (!userId) {
        userId = normalizeSlackUserId(
          candidate.user_id
          || candidate.userId
          || (candidate.user && candidate.user.id)
          || (candidate.user && candidate.user.user_id)
          || candidate.id
        );
      }
      if (!userName) {
        userName = pickSlackSessionUserName(candidate);
      }
      if (!avatarUrl) {
        avatarUrl = pickSlackSessionAvatarUrl(candidate);
      }
    };

    try {
      const pathParts = String(window.location && window.location.pathname || "")
        .split("/")
        .filter(Boolean);
      if (!teamId && pathParts[0] === "client" && pathParts[1]) {
        teamId = normalizeSlackTeamId(pathParts[1]);
      }
    } catch (_) {}

    const candidates = [];
    try { candidates.push(window.boot_data); } catch (_) {}
    try { candidates.push(window.__BOOT_DATA__); } catch (_) {}
    try { candidates.push(window.TS); } catch (_) {}
    try { candidates.push(window.TS && window.TS.boot_data); } catch (_) {}
    try { candidates.push(window.TS && window.TS.model); } catch (_) {}
    try { candidates.push(window.__INITIAL_STATE__); } catch (_) {}
    for (let i = 0; i < candidates.length; i += 1) {
      assign(candidates[i]);
      if (teamId && userId) break;
    }

    if (!userName || !avatarUrl) {
      const domIdentity = extractSlackIdentityFromDom();
      if (!userName) userName = normalizeSlackDisplayName(domIdentity.userName || "");
      if (!avatarUrl) avatarUrl = String(domIdentity.avatarUrl || "").trim();
    }

    return { teamId, userId, userName, avatarUrl };
  }

  function getSlackUserDisplayName(userPayload) {
    const user = userPayload && typeof userPayload === "object" ? userPayload : null;
    if (!user) return "";
    const profile = user.profile && typeof user.profile === "object" ? user.profile : null;
    const values = [
      profile && profile.display_name_normalized,
      profile && profile.display_name,
      profile && profile.real_name_normalized,
      profile && profile.real_name,
      user.real_name,
      user.name
    ];
    for (let i = 0; i < values.length; i += 1) {
      const name = normalizeSlackDisplayName(values[i]);
      if (name) return name;
    }
    return "";
  }

  function getSlackUserAvatar(userPayload) {
    const user = userPayload && typeof userPayload === "object" ? userPayload : null;
    if (!user) return "";
    const profile = user.profile && typeof user.profile === "object" ? user.profile : null;
    const values = [
      user.image_512,
      user.image_192,
      user.image_72,
      profile && profile.image_512,
      profile && profile.image_192,
      profile && profile.image_72,
      profile && profile.image_48
    ];
    for (let i = 0; i < values.length; i += 1) {
      const url = normalizeSlackAvatarUrl(values[i]);
      if (url) return url;
    }
    return "";
  }

  function pickSlackStatusFromDisplayInfo(displayInfo) {
    const rows = Array.isArray(displayInfo)
      ? displayInfo
      : (displayInfo ? [displayInfo] : []);
    for (let i = 0; i < rows.length; i += 1) {
      const entry = rows[i];
      if (!entry || typeof entry !== "object") continue;
      const statusIconUrl = normalizeSlackStatusIconUrl(
        entry.display_url
        || entry.image_url
        || entry.url
        || entry.icon_url
        || entry.iconUrl
        || ""
      );
      const statusIcon = normalizeSlackStatusIcon(
        entry.unicode
        || entry.emoji_string
        || entry.emoji
        || entry.display_alias
        || entry.display_name
        || entry.name
        || entry.emoji_name
        || ""
      ) || normalizeSlackStatusIconName(entry.name || entry.emoji_name || "");
      if (statusIcon || statusIconUrl) {
        return { statusIcon, statusIconUrl };
      }
    }
    return { statusIcon: "", statusIconUrl: "" };
  }

  function getSlackUserStatus(userPayload) {
    const user = userPayload && typeof userPayload === "object" ? userPayload : null;
    const profile = user && user.profile && typeof user.profile === "object" ? user.profile : null;
    if (!profile) {
      return { statusIcon: "", statusIconUrl: "", statusMessage: "" };
    }
    const fromDisplayInfo = pickSlackStatusFromDisplayInfo(profile.status_emoji_display_info || null);
    const statusIcon = normalizeSlackStatusIcon(
      profile.status_emoji
      || fromDisplayInfo.statusIcon
      || ""
    ) || fromDisplayInfo.statusIcon;
    const statusIconUrl = normalizeSlackStatusIconUrl(
      profile.status_emoji_url
      || fromDisplayInfo.statusIconUrl
      || ""
    );
    const statusMessage = normalizeSlackStatusMessage(
      profile.status_text
      || profile.status_text_canonical
      || ""
    );
    return { statusIcon, statusIconUrl, statusMessage };
  }

  function getSlackApiErrorCode(result) {
    const source = result && typeof result === "object" ? result : {};
    return String(
      source.code
      || (source.payload && source.payload.error)
      || ""
    ).trim().toLowerCase();
  }

  function getSlackApiErrorMessage(result, fallback) {
    const source = result && typeof result === "object" ? result : {};
    return String(
      source.error
      || (source.payload && source.payload.error)
      || fallback
      || ""
    ).trim();
  }

  function extractSlackIdentityFromUsersProfilePayload(payload) {
    const source = payload && typeof payload === "object" ? payload : null;
    const profile = source && source.profile && typeof source.profile === "object"
      ? source.profile
      : null;
    if (!profile) return null;
    const status = getSlackUserStatus({ profile });
    return {
      userName: getSlackUserDisplayName({ profile }),
      avatarUrl: sanitizeSlackAvatarCandidate(getSlackUserAvatar({ profile }), status.statusIconUrl),
      statusIcon: status.statusIcon,
      statusIconUrl: status.statusIconUrl,
      statusMessage: status.statusMessage
    };
  }

  function extractSlackIdentityFromUsersInfoPayload(payload) {
    const source = payload && typeof payload === "object" ? payload : null;
    const user = source && source.user && typeof source.user === "object"
      ? source.user
      : null;
    if (!user) return null;
    const status = getSlackUserStatus(user);
    return {
      userName: getSlackUserDisplayName(user),
      avatarUrl: sanitizeSlackAvatarCandidate(getSlackUserAvatar(user), status.statusIconUrl),
      statusIcon: status.statusIcon,
      statusIconUrl: status.statusIconUrl,
      statusMessage: status.statusMessage
    };
  }

  async function getSlackUserProfile(workspaceOrigin, userId) {
    const identity = {
      userName: "",
      avatarUrl: "",
      statusIcon: "",
      statusIconUrl: "",
      statusMessage: "",
      avatarErrorCode: "",
      avatarErrorMessage: ""
    };
    const applyIdentity = (nextIdentity) => {
      const candidate = nextIdentity && typeof nextIdentity === "object" ? nextIdentity : null;
      if (!candidate) return;
      if (!identity.userName) identity.userName = normalizeSlackDisplayName(candidate.userName || "");
      if (!identity.avatarUrl) {
        identity.avatarUrl = sanitizeSlackAvatarCandidate(candidate.avatarUrl || "", candidate.statusIconUrl || "");
      }
      if (!identity.statusIcon) identity.statusIcon = normalizeSlackStatusIcon(candidate.statusIcon || "");
      if (!identity.statusIconUrl) identity.statusIconUrl = normalizeSlackStatusIconUrl(candidate.statusIconUrl || "");
      if (!identity.statusMessage) identity.statusMessage = normalizeSlackStatusMessage(candidate.statusMessage || "");
    };
    const captureAvatarError = (result, fallbackMessage) => {
      if (identity.avatarUrl) return;
      const code = getSlackApiErrorCode(result);
      const message = getSlackApiErrorMessage(result, fallbackMessage);
      if (code && !identity.avatarErrorCode) identity.avatarErrorCode = code;
      if (message && !identity.avatarErrorMessage) identity.avatarErrorMessage = message;
    };
    const normalizedUserId = normalizeSlackUserId(userId);
    const targetOrigins = [];
    const pushOrigin = (value) => {
      const normalized = normalizeSlackWorkspaceOrigin(value);
      if (!normalized) return;
      if (!targetOrigins.includes(normalized)) targetOrigins.push(normalized);
    };
    pushOrigin(workspaceOrigin);
    pushOrigin(SLACK_WEB_API_ORIGIN);

    for (let i = 0; i < targetOrigins.length; i += 1) {
      const origin = targetOrigins[i];
      const selfProfile = await postSlackApi(origin, "/api/users.profile.get", {
        _x_reason: "zip-auth-profile-self"
      });
      if (selfProfile && selfProfile.ok) {
        applyIdentity(extractSlackIdentityFromUsersProfilePayload(selfProfile.payload));
      } else {
        captureAvatarError(selfProfile, "users.profile.get(self) failed.");
      }

      if ((!identity.userName || !identity.avatarUrl) && normalizedUserId) {
        const profileById = await postSlackApi(origin, "/api/users.profile.get", {
          user: normalizedUserId,
          _x_reason: "zip-auth-profile-user"
        });
        if (profileById && profileById.ok) {
          applyIdentity(extractSlackIdentityFromUsersProfilePayload(profileById.payload));
        } else {
          captureAvatarError(profileById, "users.profile.get(user) failed.");
        }
      }

      if ((!identity.userName || !identity.avatarUrl) && normalizedUserId) {
        const info = await postSlackApi(origin, "/api/users.info", {
          user: normalizedUserId,
          _x_reason: "zip-auth-profile-info"
        });
        if (info && info.ok) {
          applyIdentity(extractSlackIdentityFromUsersInfoPayload(info.payload));
        } else {
          captureAvatarError(info, "users.info failed.");
        }
      }

      if (identity.userName && identity.avatarUrl) break;
    }

    if (
      !identity.userName
      && !identity.avatarUrl
      && !identity.statusIcon
      && !identity.statusMessage
      && !identity.avatarErrorCode
      && !identity.avatarErrorMessage
    ) {
      return null;
    }
    return identity;
  }

  async function slackAuthTestAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const session = extractSlackSessionIdentity();
    const expectedTeamId = normalizeSlackTeamId(
      (inner && (inner.teamId || inner.team_id))
      || session.teamId
    );
    const pathname = String(window.location && window.location.pathname || "").toLowerCase();
    const looksSignedIn = pathname.indexOf("/signin") === -1;
    const hasSessionSignals = !!(
      session.userId
      || session.teamId
      || (
        typeof window !== "undefined"
        && (
          window.boot_data
          || window.__BOOT_DATA__
          || (window.TS && (window.TS.boot_data || window.TS.model))
          || window.__INITIAL_STATE__
        )
      )
    );
    const token = resolveSlackApiToken();
    if (!token) {
      if (looksSignedIn && hasSessionSignals) {
        return {
          ok: true,
          ready: true,
          api_validated: false,
          user_id: session.userId || "",
          team_id: session.teamId || "",
          user_name: session.userName || "",
          avatar_url: session.avatarUrl || "",
          workspace_origin: workspaceOrigin,
          session_only: true,
          warning: "Slack session detected; waiting for web token capture."
        };
      }
      return { ok: false, error: "Slack session token not found yet. Finish login in the adobedx.slack.com tab." };
    }
    const auth = await postSlackApi(workspaceOrigin, "/api/auth.test", {
      _x_reason: "zip-auth-test"
    }, {
      expectedTeamId
    });
    if (!auth.ok) {
      if (looksSignedIn && hasSessionSignals) {
        return {
          ok: true,
          ready: true,
          api_validated: false,
          user_id: session.userId || "",
          team_id: session.teamId || "",
          user_name: session.userName || "",
          avatar_url: session.avatarUrl || "",
          workspace_origin: workspaceOrigin,
          session_token: token || "",
          warning: auth.error || "auth.test failed but Slack web session appears active."
        };
      }
      return auth;
    }
    const payload = auth.payload || {};
    const userId = String(payload.user_id || payload.user || session.userId || "").trim();
    const teamId = String(payload.team_id || payload.team || session.teamId || "").trim();
    let userName = normalizeSlackDisplayName(session.userName || "");
    let avatarUrl = sanitizeSlackAvatarCandidate(session.avatarUrl || "", "");
    let statusIcon = "";
    let statusIconUrl = "";
    let statusMessage = "";
    let avatarErrorCode = "";
    let avatarErrorMessage = "";
    const profile = await getSlackUserProfile(workspaceOrigin, userId).catch(() => null);
    if (profile) {
      if (!userName) userName = normalizeSlackDisplayName(profile.userName || "");
      if (!statusIcon) statusIcon = normalizeSlackStatusIcon(profile.statusIcon || "");
      if (!statusIconUrl) statusIconUrl = normalizeSlackStatusIconUrl(profile.statusIconUrl || "");
      if (!statusMessage) statusMessage = normalizeSlackStatusMessage(profile.statusMessage || "");
      const profileAvatarUrl = sanitizeSlackAvatarCandidate(profile.avatarUrl || "", statusIconUrl || profile.statusIconUrl || "");
      if (profileAvatarUrl) avatarUrl = profileAvatarUrl;
      avatarUrl = sanitizeSlackAvatarCandidate(avatarUrl, statusIconUrl);
      if (!avatarUrl) {
        avatarErrorCode = String(profile.avatarErrorCode || "").trim().toLowerCase();
        avatarErrorMessage = String(profile.avatarErrorMessage || "").trim();
      }
    }
    if (!userName || !avatarUrl) {
      const domIdentity = extractSlackIdentityFromDom();
      if (!userName) userName = normalizeSlackDisplayName(domIdentity.userName || "");
      if (!avatarUrl) avatarUrl = sanitizeSlackAvatarCandidate(domIdentity.avatarUrl || "", statusIconUrl);
    }
    avatarUrl = sanitizeSlackAvatarCandidate(avatarUrl, statusIconUrl);
    if (avatarUrl) {
      avatarErrorCode = "";
      avatarErrorMessage = "";
    }
    return {
      ok: true,
      ready: true,
      api_validated: true,
      user_id: userId,
      team_id: teamId,
      user_name: userName,
      avatar_url: avatarUrl,
      status_icon: statusIcon,
      status_icon_url: statusIconUrl,
      status_message: statusMessage,
      avatar_error_code: avatarErrorCode,
      avatar_error: avatarErrorMessage,
      workspace_origin: workspaceOrigin,
      session_token: token || ""
    };
  }

  async function slackSendMarkdownToSelfAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const markdownText = String((inner && (inner.markdownText || inner.text || inner.messageText)) || "").trim();
    if (!markdownText) {
      return { ok: false, error: "Slack message body is empty." };
    }
    const session = extractSlackSessionIdentity();
    let userId = normalizeSlackUserId((inner && (inner.userId || inner.user_id)) || session.userId);
    let teamId = normalizeSlackTeamId(session.teamId);
    let userName = normalizeSlackDisplayName(session.userName || "");
    let avatarUrl = sanitizeSlackAvatarCandidate(session.avatarUrl || "", "");

    const auth = await postSlackApi(workspaceOrigin, "/api/auth.test", {
      _x_reason: "zip-slack-it-to-me-auth"
    });
    if (!auth || !auth.ok) {
      return {
        ok: false,
        error: String((auth && auth.error) || "Slack session unavailable.")
      };
    }
    const authPayload = auth.payload && typeof auth.payload === "object" ? auth.payload : {};
    if (!userId) {
      userId = normalizeSlackUserId(authPayload.user_id || authPayload.user);
    }
    if (!teamId) {
      teamId = normalizeSlackTeamId(authPayload.team_id || authPayload.team);
    }
    if (!userId) {
      return { ok: false, error: "Unable to resolve Slack user identity for @ME delivery." };
    }

    const profile = await getSlackUserProfile(workspaceOrigin, userId).catch(() => null);
    if (profile) {
      if (!userName) userName = normalizeSlackDisplayName(profile.userName || "");
      const profileAvatarUrl = sanitizeSlackAvatarCandidate(
        profile.avatarUrl || "",
        profile.statusIconUrl || ""
      );
      if (profileAvatarUrl) avatarUrl = profileAvatarUrl;
    }
    if (!userName || !avatarUrl) {
      const domIdentity = extractSlackIdentityFromDom();
      if (!userName) userName = normalizeSlackDisplayName(domIdentity.userName || "");
      if (!avatarUrl) avatarUrl = sanitizeSlackAvatarCandidate(domIdentity.avatarUrl || "", "");
    }

    const dmOpen = await postSlackApi(workspaceOrigin, "/api/conversations.open", {
      users: userId,
      return_im: "true",
      _x_reason: "zip-open-self-dm"
    });
    if (!dmOpen || !dmOpen.ok) {
      return {
        ok: false,
        error: String((dmOpen && dmOpen.error) || "Unable to open Slack DM channel.")
      };
    }
    const dmPayload = dmOpen.payload && typeof dmOpen.payload === "object" ? dmOpen.payload : {};
    const dmChannel = dmPayload.channel && typeof dmPayload.channel === "object" ? dmPayload.channel : {};
    const channelId = String(dmChannel.id || dmPayload.channel_id || dmPayload.channel || "").trim();
    if (!channelId) {
      return { ok: false, error: "Unable to resolve Slack DM channel." };
    }

    const postFields = {
      channel: channelId,
      text: markdownText,
      mrkdwn: true,
      parse: "none",
      unfurl_links: "false",
      unfurl_media: "false",
      _x_reason: "zip-slack-it-to-me"
    };
    delete postFields.thread_ts;
    delete postFields.reply_broadcast;
    const post = await postSlackApi(workspaceOrigin, "/api/chat.postMessage", postFields);
    if (!post || !post.ok) {
      return {
        ok: false,
        error: String((post && post.error) || "Unable to send Slack DM.")
      };
    }
    const postPayload = post.payload && typeof post.payload === "object" ? post.payload : {};
    const postedTs = String(postPayload.ts || (postPayload.message && postPayload.message.ts) || "").trim();
    return {
      ok: true,
      channel: String(postPayload.channel || channelId || userId).trim(),
      ts: postedTs,
      user_id: userId,
      team_id: teamId,
      user_name: userName,
      avatar_url: avatarUrl,
      unread_marked: false
    };
  }

  async function slackMarkUnreadAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const channelId = String((inner && (inner.channelId || inner.channel_id || inner.channel)) || "").trim();
    const messageTs = String((inner && (inner.ts || inner.messageTs || inner.message_ts)) || "").trim();
    if (!channelId || !messageTs) {
      return { ok: false, error: "Slack unread marker requires channel and ts." };
    }
    const unreadMarked = await markSlackMessageUnread(
      workspaceOrigin,
      channelId,
      messageTs,
      "zip-slack-it-to-me-bg-fallback"
    );
    if (!unreadMarked) {
      return { ok: false, error: "Unable to mark Slack DM as unread." };
    }
    return {
      ok: true,
      channel: channelId,
      ts: messageTs,
      unread_marked: true
    };
  }

  async function slackSendToSingularityAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const channelId = String((inner && (inner.channelId || inner.channel_id)) || "").trim();
    if (!channelId) {
      return { ok: false, error: "Slack channel ID is required." };
    }

    let singularityUserId = String((inner && inner.singularityUserId) || "").trim();
    const fallbackMentionRaw = decodeSlackEntityText(String((inner && inner.mention) || "").trim());
    const fallbackMention = (function normalizeMention(value) {
      const raw = String(value || "").trim();
      if (!raw) return "";
      if (/^<@[UW][A-Z0-9]{8,}>$/i.test(raw)) return raw;
      const plain = raw.startsWith("@") ? raw.slice(1).trim() : raw;
      if (!plain) return "";
      return "@" + plain;
    })(fallbackMentionRaw);
    if (!singularityUserId && /^<@[UW][A-Z0-9]{8,}>$/i.test(fallbackMention)) {
      const fromMention = fallbackMention.match(/^<@([UW][A-Z0-9]{8,})>$/i);
      singularityUserId = fromMention ? String(fromMention[1] || "").trim().toUpperCase() : "";
    }
    if (!singularityUserId && fallbackMention.startsWith("@")) {
      const resolvedUserId = await resolveSlackUserIdByMention(workspaceOrigin, fallbackMention).catch(() => "");
      if (resolvedUserId) singularityUserId = resolvedUserId;
    }
    if (!singularityUserId && fallbackMention.startsWith("@")) {
      const resolvedFromMembers = await resolveSlackUserIdFromConversationMembers(
        workspaceOrigin,
        channelId,
        fallbackMention
      ).catch(() => "");
      if (resolvedFromMembers) singularityUserId = resolvedFromMembers;
    }
    if (!singularityUserId && fallbackMention.startsWith("@")) {
      const resolvedFromChannel = await resolveSlackUserIdFromChannelHistory(
        workspaceOrigin,
        channelId,
        fallbackMention
      ).catch(() => "");
      if (resolvedFromChannel) singularityUserId = resolvedFromChannel;
    }
    if (!singularityUserId && fallbackMention.startsWith("@")) {
      return {
        ok: false,
        code: "singularity_user_unresolved",
        error: "Unable to resolve configured Singularity mention to a Slack user ID. Set slacktivation.singularity_mention to a real Slack mention like <@U123...>."
      };
    }
    const question = decodeSlackEntityText(String((inner && (inner.messageText || inner.text || inner.question)) || "")).trim();
    if (!question) {
      return { ok: false, error: "Question text is empty." };
    }

    let bodyText = question;
    const singularityTag = singularityUserId ? ("<@" + singularityUserId + ">") : "";
    const stripPrefix = (text, prefix) => {
      const value = String(text || "");
      const match = String(prefix || "").trim();
      if (!match) return value;
      if (value.toLowerCase().startsWith(match.toLowerCase())) {
        return value.slice(match.length).trim();
      }
      return value;
    };
    if (singularityTag) {
      bodyText = stripPrefix(bodyText, singularityTag);
    }
    if (fallbackMention) {
      bodyText = stripPrefix(bodyText, fallbackMention);
    }
    const mentionPrefix = singularityTag || fallbackMention;
    const text = mentionPrefix ? (mentionPrefix + " " + bodyText).trim() : bodyText;
    const session = extractSlackSessionIdentity();
    const clientContextTeamId = normalizeSlackTeamId(
      (inner && (inner.teamId || inner.team_id))
      || session.teamId
    );
    const urlsForUnfurl = extractUrlsFromText(bodyText);
    const fields = {
      channel: channelId,
      text,
      ts: generateSlackLikeTs(),
      type: "message",
      xArgs: "",
      include_channel_perm_error: "true",
      client_msg_id: generateSlackClientMessageId(),
      link_names: "1",
      mrkdwn: "true",
      parse: singularityTag ? "none" : "full",
      _x_reason: "webapp_message_send",
      _x_mode: "online",
      _x_sonic: "true",
      _x_app_name: "client"
    };
    if (clientContextTeamId) fields.client_context_team_id = clientContextTeamId;
    if (urlsForUnfurl.length) fields.unfurl = urlsForUnfurl.map((url) => ({ url }));

    const postToChannel = (targetChannelId, reasonTag) => postSlackApi(workspaceOrigin, "/api/chat.postMessage", {
      ...fields,
      channel: targetChannelId,
      _x_reason: reasonTag || String(fields._x_reason || "webapp_message_send")
    });

    let effectiveChannelId = channelId;
    let payload = await postToChannel(effectiveChannelId, "webapp_message_send");
    const payloadCode = getSlackApiFailureCode(
      payload && payload.payload && typeof payload.payload === "object" ? payload.payload : null,
      String((payload && (payload.code || payload.error)) || "")
    );
    const shouldRecoverWithDmOpen = (
      !payload
      || payload.ok !== true
    ) && singularityUserId && (payloadCode === "channel_not_found" || payloadCode === "not_in_channel");
    if (shouldRecoverWithDmOpen) {
      const dmOpen = await postSlackApi(workspaceOrigin, "/api/conversations.open", {
        users: singularityUserId,
        return_im: "true",
        _x_reason: "zip-open-singularity-dm-recover"
      });
      if (dmOpen && dmOpen.ok) {
        const dmPayload = dmOpen.payload && typeof dmOpen.payload === "object" ? dmOpen.payload : {};
        const dmChannel = dmPayload.channel && typeof dmPayload.channel === "object" ? dmPayload.channel : {};
        const recoveredChannelId = String(dmChannel.id || dmPayload.channel_id || dmPayload.channel || "").trim();
        if (recoveredChannelId) {
          effectiveChannelId = recoveredChannelId;
          payload = await postToChannel(effectiveChannelId, "webapp_message_send_dm_recover");
        }
      }
    }
    if (!payload.ok) return payload;

    const slack = payload.payload || {};
    const messageTs = String(slack.ts || (slack.message && slack.message.ts) || "").trim();
    const postedChannel = String(slack.channel || effectiveChannelId || channelId).trim();
    if (postedChannel && messageTs) {
      await slackConversationsMark(workspaceOrigin, postedChannel, messageTs, "viewed").catch(() => {});
    }

    return {
      ok: true,
      channel: postedChannel,
      ts: messageTs,
      parent_ts: messageTs,
      thread_ts: messageTs,
      message: slack.message || null
    };
  }

  async function slackPollSingularityThreadAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const channelId = String((inner && (inner.channelId || inner.channel_id)) || "").trim();
    const parentTs = String((inner && (inner.parentTs || inner.parent_ts || inner.threadTs || inner.thread_ts)) || "").trim();
    if (!channelId || !parentTs) {
      return { ok: false, error: "Slack channel/thread metadata is required." };
    }
    const session = extractSlackSessionIdentity();

    const limitRaw = Number(inner && inner.limit);
    const limit = Number.isFinite(limitRaw) && limitRaw > 0 ? Math.min(Math.trunc(limitRaw), 200) : 40;
    const cachedLatestUpdates = inner && inner.cached_latest_updates && typeof inner.cached_latest_updates === "object"
      ? inner.cached_latest_updates
      : inner && inner.cachedLatestUpdates && typeof inner.cachedLatestUpdates === "object"
        ? inner.cachedLatestUpdates
        : null;
    const repliesFields = {
      channel: channelId,
      ts: parentTs,
      inclusive: "true",
      oldest: parentTs,
      limit,
      _x_reason: "history-api/fetchReplies"
    };
    if (cachedLatestUpdates && Object.keys(cachedLatestUpdates).length) {
      repliesFields.cached_latest_updates = cachedLatestUpdates;
    }
    const repliesResponse = await postSlackApi(workspaceOrigin, "/api/conversations.replies", repliesFields);
    if (!repliesResponse.ok) return repliesResponse;

    const payload = repliesResponse.payload || {};
    const messages = Array.isArray(payload.messages) ? payload.messages.slice() : [];
    messages.sort((a, b) => slackTsToEpochMs(a && a.ts) - slackTsToEpochMs(b && b.ts));

    const singularityOptions = {
      singularityUserId: inner && inner.singularityUserId,
      singularityNamePattern: inner && inner.singularityNamePattern
    };
    const postingUserId = normalizeSlackUserId(session.userId);
    const explicitSingularityTarget = !!(
      normalizeSlackUserId(singularityOptions && singularityOptions.singularityUserId)
      || String(singularityOptions && singularityOptions.singularityNamePattern || "").trim()
    );
    const preferredReplies = [];
    const fallbackReplies = [];
    const nonSingularityMessages = [];
    for (let i = 0; i < messages.length; i += 1) {
      const message = messages[i];
      if (!message || typeof message !== "object") continue;
      const ts = String(message.ts || "").trim();
      if (!ts || ts === parentTs) continue;
      const threadTs = String(message.thread_ts || "").trim();
      if (threadTs && threadTs !== parentTs) continue;

      const messageUserId = normalizeSlackUserId(
        message.user
        || (message.user_profile && message.user_profile.id)
        || ""
      );
      const fromPostingUser = !!(postingUserId && messageUserId && messageUserId === postingUserId);
      const fromSingularity = isSingularityMessage(message, singularityOptions);
      if (fromSingularity) {
        preferredReplies.push(message);
        continue;
      }
      if (fromPostingUser) continue;
      nonSingularityMessages.push(message);
      if (!explicitSingularityTarget) fallbackReplies.push(message);
    }
    const replyMessages = preferredReplies.length ? preferredReplies : fallbackReplies;

    const latestReply = replyMessages.length ? replyMessages[replyMessages.length - 1] : null;
    const finalMarkerRegex = String((inner && inner.finalMarkerRegex) || SLACK_DEFAULT_FINAL_MARKER_REGEX).trim();
    let finalReply = null;
    for (let i = replyMessages.length - 1; i >= 0; i -= 1) {
      const message = replyMessages[i];
      const messageText = extractSlackMessageText(message);
      if (
        hasSlackFinalMarker(message, finalMarkerRegex)
        || hasSingularityCompletionFooterText(messageText)
      ) {
        finalReply = replyMessages[i];
        break;
      }
    }

    const latestReplyTs = String((latestReply && latestReply.ts) || "").trim();
    const latestReplyText = extractSlackMessageText(latestReply);
    const finalReplyTs = String((finalReply && finalReply.ts) || "").trim();
    const finalReplyText = extractSlackMessageText(finalReply);
    const allReplies = replyMessages.map((message) => ({
      ts: String((message && message.ts) || "").trim(),
      text: extractSlackMessageText(message),
      hasFinalMarker: hasSlackFinalMarker(message, finalMarkerRegex),
      hasCompletionFooter: hasSingularityCompletionFooterText(extractSlackMessageText(message)),
      isAck: isSingularityAckMessageText(extractSlackMessageText(message))
    })).filter((row) => row.ts || row.text);

    const dedupedReplyRows = [];
    const seenReplyNorms = new Set();
    for (let i = 0; i < allReplies.length; i += 1) {
      const row = allReplies[i];
      const text = String((row && row.text) || "").trim();
      if (!text) continue;
      const norm = normalizeSlackTextForDedup(text);
      if (!norm || seenReplyNorms.has(norm)) continue;

      if (dedupedReplyRows.length) {
        const last = dedupedReplyRows[dedupedReplyRows.length - 1];
        if (
          last
          && typeof last.norm === "string"
          && norm.length > last.norm.length + 40
          && norm.includes(last.norm)
        ) {
          dedupedReplyRows.pop();
          seenReplyNorms.delete(last.norm);
        }
      }

      dedupedReplyRows.push({
        text,
        norm,
        isAck: !!(row && row.isAck)
      });
      seenReplyNorms.add(norm);
    }

    let allReplyTexts = dedupedReplyRows.map((row) => row.text);
    if (allReplyTexts.length > 1) {
      const nonAckTexts = dedupedReplyRows
        .filter((row) => !row.isAck)
        .map((row) => row.text);
      if (nonAckTexts.length) allReplyTexts = nonAckTexts;
    }

    const combinedReplyText = allReplyTexts.join("\n\n").trim();
    const hasCompletionFooter = allReplies.some((row) => row && row.hasCompletionFooter);
    const hasSourcesFooter = allReplyTexts.some((text) => hasSlackSourcesFooterText(text));
    const ackOnly = dedupedReplyRows.length === 1 && !!(dedupedReplyRows[0] && dedupedReplyRows[0].isAck);
    const nonSingularityReplies = nonSingularityMessages.map((message) => ({
      ts: String((message && message.ts) || "").trim(),
      text: extractSlackMessageText(message)
    })).filter((row) => row.ts || row.text);
    const latestNonSingularityReply = nonSingularityReplies.length
      ? nonSingularityReplies[nonSingularityReplies.length - 1]
      : null;
    const cachedLatestUpdatesOut = Object.create(null);
    cachedLatestUpdatesOut[parentTs] = parentTs;
    allReplies.forEach((row) => {
      const ts = String(row && row.ts || "").trim();
      if (ts) cachedLatestUpdatesOut[ts] = ts;
    });
    nonSingularityReplies.forEach((row) => {
      const ts = String(row && row.ts || "").trim();
      if (ts) cachedLatestUpdatesOut[ts] = ts;
    });

    if (latestReplyTs) {
      await slackThreadMark(workspaceOrigin, channelId, parentTs, latestReplyTs, false).catch(() => {});
      await slackConversationsMark(workspaceOrigin, channelId, latestReplyTs, "viewed").catch(() => {});
    }

    return {
      ok: true,
      status: (finalReply || hasCompletionFooter || hasSourcesFooter) ? "final" : "pending",
      channel: channelId,
      parent_ts: parentTs,
      latestReplyTs,
      latestReplyText,
      finalReplyTs,
      finalReplyText,
      hasFinalMarker: !!finalReply || hasCompletionFooter || hasSourcesFooter,
      hasCompletionFooter,
      hasSourcesFooter,
      ackOnly,
      final: !!finalReply || hasCompletionFooter || hasSourcesFooter,
      allReplies,
      allReplyTexts,
      combinedReplyText,
      repliesCount: replyMessages.length,
      singularityRepliesCount: replyMessages.length,
      nonSingularityRepliesCount: nonSingularityReplies.length,
      latestNonSingularityReplyTs: String((latestNonSingularityReply && latestNonSingularityReply.ts) || "").trim(),
      latestNonSingularityReplyText: String((latestNonSingularityReply && latestNonSingularityReply.text) || "").trim(),
      cachedLatestUpdates: cachedLatestUpdatesOut,
      messageCount: messages.length
    };
  }

  async function slackDeleteMessage(workspaceOrigin, channelId, ts) {
    if (!channelId || !ts) return { ok: false, error: "Slack delete metadata is missing." };
    return postSlackApi(workspaceOrigin, "/api/chat.delete", {
      channel: channelId,
      ts,
      _x_reason: "zip-thread-delete"
    });
  }

  async function slackDeleteSingularityThreadAction(inner) {
    if (!isSlackPage()) {
      return { ok: false, error: "Not a Slack tab. Open Slack login first." };
    }
    ensureSlackTokenBridgeInstalled();
    const workspaceOrigin = normalizeSlackWorkspaceOrigin(inner && inner.workspaceOrigin);
    const channelId = String((inner && (inner.channelId || inner.channel_id)) || "").trim();
    const parentTs = String((inner && (inner.parentTs || inner.parent_ts || inner.threadTs || inner.thread_ts)) || "").trim();
    if (!channelId || !parentTs) {
      return { ok: false, error: "Slack channel/thread metadata is required." };
    }

    const limitRaw = Number(inner && inner.limit);
    const limit = Number.isFinite(limitRaw) && limitRaw > 0 ? Math.min(Math.trunc(limitRaw), 200) : 120;
    const repliesResponse = await postSlackApi(workspaceOrigin, "/api/conversations.replies", {
      channel: channelId,
      ts: parentTs,
      inclusive: "true",
      oldest: parentTs,
      limit,
      _x_reason: "history-api/fetchReplies"
    });
    if (!repliesResponse.ok) return repliesResponse;

    const payload = repliesResponse.payload || {};
    const rows = Array.isArray(payload.messages) ? payload.messages.slice() : [];
    const threadMessages = rows
      .filter((message) => {
        if (!message || typeof message !== "object") return false;
        const ts = String(message.ts || "").trim();
        if (!ts) return false;
        if (ts === parentTs) return true;
        const threadTs = String(message.thread_ts || "").trim();
        return !threadTs || threadTs === parentTs;
      })
      .map((message) => String((message && message.ts) || "").trim())
      .filter(Boolean);

    if (!threadMessages.length) threadMessages.push(parentTs);

    // Delete newest first to reduce orphaning if deletion partially fails.
    threadMessages.sort((a, b) => slackTsToEpochMs(b) - slackTsToEpochMs(a));

    const deletedTs = [];
    const failedDeletes = [];
    for (let i = 0; i < threadMessages.length; i += 1) {
      const ts = threadMessages[i];
      const deletion = await slackDeleteMessage(workspaceOrigin, channelId, ts);
      if (deletion && deletion.ok) {
        deletedTs.push(ts);
      } else {
        failedDeletes.push({
          ts,
          error: String((deletion && (deletion.error || deletion.message)) || "Unable to delete message.")
        });
      }
    }

    return {
      ok: failedDeletes.length === 0 || deletedTs.length > 0,
      channel: channelId,
      parent_ts: parentTs,
      deletedCount: deletedTs.length,
      failedCount: failedDeletes.length,
      totalMessages: threadMessages.length,
      deletedTs,
      failedDeletes
    };
  }

  function openZipOptionsFromContent() {
    sendRuntimeMessage({ type: "ZIP_OPEN_OPTIONS" });
  }

  function removeZipKeyBanner() {
    const existing = document.getElementById(ZIP_KEY_BANNER_ID);
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
  }

  function ensureZipKeyBanner() {
    if (document.getElementById(ZIP_KEY_BANNER_ID)) return;
    if (!document || !document.body) return;

    const banner = document.createElement("div");
    banner.id = ZIP_KEY_BANNER_ID;
    banner.setAttribute("role", "status");
    banner.style.position = "fixed";
    banner.style.top = "12px";
    banner.style.right = "12px";
    banner.style.zIndex = "2147483647";
    banner.style.background = "#f5f5f5";
    banner.style.color = "#202020";
    banner.style.border = "1px solid #b8b8b8";
    banner.style.borderRadius = "8px";
    banner.style.boxShadow = "0 6px 20px rgba(0,0,0,0.18)";
    banner.style.fontFamily = "Adobe Clean, Segoe UI, system-ui, sans-serif";
    banner.style.fontSize = "12px";
    banner.style.lineHeight = "1.35";
    banner.style.maxWidth = "320px";
    banner.style.padding = "10px 12px";
    banner.style.display = "flex";
    banner.style.alignItems = "center";
    banner.style.gap = "8px";

    const text = document.createElement("button");
    text.type = "button";
    text.style.all = "unset";
    text.style.cursor = "pointer";
    text.style.color = "#1473e6";
    text.style.textDecoration = "underline";
    text.textContent = "ZipTool: Please drop ZIP.KEY to SLACKTIVATE";
    text.addEventListener("click", () => openZipOptionsFromContent());

    const close = document.createElement("button");
    close.type = "button";
    close.setAttribute("aria-label", "Dismiss ZIP.KEY banner");
    close.style.border = "none";
    close.style.background = "transparent";
    close.style.color = "#505050";
    close.style.cursor = "pointer";
    close.style.fontSize = "14px";
    close.style.lineHeight = "1";
    close.textContent = "x";
    close.addEventListener("click", () => removeZipKeyBanner());

    banner.appendChild(text);
    banner.appendChild(close);
    document.body.appendChild(banner);
  }

  function syncZipKeyBanner() {
    if (!isZendeskPage()) return;
    const sent = sendRuntimeMessage({ type: "ZIP_CHECK_SECRETS" }, (response, runtimeError) => {
      if (runtimeError) {
        ensureZipKeyBanner();
        return;
      }
      const ok = !!(response && response.ok);
      if (ok) removeZipKeyBanner();
      else ensureZipKeyBanner();
    });
    if (!sent) {
      ensureZipKeyBanner();
    }
  }

  if (isSlackPage()) {
    // Defer bridge injection until a Slack action requires API access.
    readCapturedSlackToken();
  }

  // Login/sign-in Zendesk pages do not need ZIP runtime wiring and can have
  // transient extension runtime invalidation during reload/update.
  if (isZendeskAuthPage()) {
    // Run one authoritative probe so background auth state flips immediately
    // after Zendesk redirects to login/auth pages.
    probeZendeskSession({ reason: "auth_page_bootstrap" })
      .catch(() => {
        emitZendeskLogout("auth_page_probe_failed", 401);
      });
    return;
  }

  if (isZendeskPage()) {
    installZendeskSessionObservers();
    syncZipKeyBanner();
    window.addEventListener("focus", () => syncZipKeyBanner());
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) syncZipKeyBanner();
    });
  }

  const runtime = getChromeRuntime();
  if (runtime && runtime.onMessage && typeof runtime.onMessage.addListener === "function") {
    runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === "ZIP_KEY_CLEARED") {
      syncZipKeyBanner();
      return;
    }
    if (msg && msg.type === "ZIP_SESSION_PROBE") {
      // Authoritative Zendesk auth probe used by background/sidepanel coordination.
      probeZendeskSession({
        url: msg.url || SESSION_URL,
        reason: msg.source || "zip_session_probe"
      })
        .then((result) => sendResponse({
          ok: !!(result && result.ok),
          status: Number(result && result.status) || 0,
          payload: result && result.payload ? result.payload : null,
          error: result && result.error ? result.error : ""
        }))
        .catch((err) => sendResponse({
          ok: false,
          status: 0,
          payload: null,
          error: err && err.message ? err.message : "Zendesk session probe failed."
        }));
      return true;
    }
    if (!msg || msg.type !== "ZIP_FROM_BACKGROUND") return;
    const { requestId, inner } = msg;
    if (!inner || !requestId) {
      sendResponse({ type: "ZIP_RESPONSE", requestId, error: "Invalid message" });
      return;
    }
    const run = async () => {
      try {
        if (inner.action === "slackAuthTest") {
          const result = await slackAuthTestAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "slackSendMarkdownToSelf") {
          const result = await slackSendMarkdownToSelfAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "slackMarkUnread") {
          const result = await slackMarkUnreadAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "slackSendToSingularity") {
          const result = await slackSendToSingularityAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "slackPollSingularityThread") {
          const result = await slackPollSingularityThreadAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "slackDeleteSingularityThread") {
          const result = await slackDeleteSingularityThreadAction(inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "fetch") {
          const result = await fetchJson(inner.url);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "getMe") {
          const result = await getMe();
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTickets") {
          const result = await loadTickets(inner.userId || inner.user_id || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTicketsByOrg") {
          const result = await loadTicketsByOrg(inner.orgId || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTicketsBySearchQuery") {
          const result = await loadTicketsBySearchQuery(inner.query || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadOrganizations") {
          const result = await loadOrganizations();
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadViews") {
          const result = await loadViews();
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadViewCount") {
          const result = await loadViewCount(inner.viewId || "");
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadViewCountsMany") {
          const result = await loadViewCountsMany(inner.viewIds || []);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadOrganizationCount") {
          const result = await loadOrganizationCount(inner.orgId || "");
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTicketsByView") {
          const result = await loadTicketsByView(inner.viewId || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadGroupAgents") {
          const result = await loadGroupAgents(inner.groupId || "");
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadAllGroupsWithMembers") {
          const result = await loadAllGroupsWithMembers();
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTicketsByGroupId") {
          const result = await loadTicketsByGroupId(inner.groupId || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadGroupTicketCount") {
          const result = await loadGroupTicketCount(inner.groupId || "");
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadTicketsByAssigneeId") {
          const result = await loadTicketsByAssigneeId(inner.userId || inner.user_id || "", inner);
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "loadAssigneeTicketCount") {
          const result = await loadAssigneeTicketCount(inner.userId || "");
          return { type: "ZIP_RESPONSE", requestId, result };
        }
        if (inner.action === "logout") {
          return { type: "ZIP_RESPONSE", requestId, result: { ok: true } };
        }
        return { type: "ZIP_RESPONSE", requestId, error: "Unknown action" };
      } catch (err) {
        return { type: "ZIP_RESPONSE", requestId, error: (err && err.message) || "Unknown error" };
      }
    };
      run().then(sendResponse);
      return true;
    });
  }
})();
